    # -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 20:10:34 2019

@author: Wenzhao.Yang
"""

import json
import os
import sys
import jinja2
from Utlities.helpfunc import AddQuoteToString, checkDatePattern, getMonthList, convertAppendixToDict, convertDictTOList, writeFile
#%%
class query():
    
    #input variable json_name
    #input variable
    def __init__(self):
        self.database = None
        self.paras = None
        self.query = None
        self.json_path = None
        self.dir_path = None
        self.tempVars_dsdk = {}
        self.tempVars_js = {}

        
#%%
    #read parameters
    #take path of json file folder location and json file name to read json
    def read_paras(self, path, json_file):
        try: 
            self.json_path = os.path.join(path,json_file)
            self.dir_path = os.path.dirname(os.path.dirname(self.json_path))
            with open(self.json_path) as file:
                self.paras = json.load(file)
        except:
            print('{} does not exist'.format(json_file))
            sys.exit(2)
    
#%%
    #function to load all paras for dsdk json
    def dsdk_load_paras(self):
        
        if 'dsdk' in self.json_path:
            
            
            startdate = self.paras['params']['dates']['start']
            enddate = self.paras['params']['dates']['end']
            
            campagin_info = self.paras['params']['campaign_info']['campaigns_by_adserver']
            namespace_id = campagin_info[0]['namespace_id']
            site_identifier = campagin_info[0]['site_identifier']
            campaign_identifier = campagin_info[0]['campaign_identifier']
            placement_identifier = campagin_info[0]['placement_identifier']
            tag_id = self.paras['params']['conversion_data']['tag_id']
            conversion_type_code= AddQuoteToString(self.paras['params']['conversion_data']['conversion_type_codes'])
            
            #get any custom grouping info
            file_name = self.paras['params']['custom_segment']['filename']
            segment_name = self.paras['params']['custom_segment']['segment_name']
            group_by_name = self.paras['params']['custom_segment']['groupby']
            
            #template name
            template_name = self.paras['params']['pathinfo']['templateName']
            
            #output query name
            output_name = self.paras['params']['pathinfo']['SaveAs']
            
            #Set up global variable
            global success_dsdk
            success_dsdk = 1
            
            
            #Check date format and create a list contains YYYY_MM
            if not checkDatePattern(startdate) and checkDatePattern(enddate):
                print("Please check start/end date value and format(yyyy-mm-dd)")
                #break process
                success_dsdk = 0
                sys.exit(2)
                
            else:
                self.tempVars_dsdk['start_date'] = startdate
                self.tempVars_dsdk['end_date'] = enddate
                self.tempVars_dsdk['month_list'] = getMonthList(startdate,enddate)

            self.tempVars_dsdk['campaign_identifier'] = campaign_identifier
            self.tempVars_dsdk['site_identifier'] = site_identifier
            self.tempVars_dsdk['namespace_id'] = namespace_id
            if template_name not in os.listdir(os.path.join(self.dir_path,'template')):
                print ("Cannot locate {} in template folder".format(template_name))
                success_dsdk = 0
                sys.exit(2)
            else:
                self.tempVars_dsdk['template_name'] = template_name
            
            if output_name in os.listdir(os.path.join(self.dir_path,'query')):
                print("file with the same name as {} already exist in query folder, please remove duplicates or rename output file".format(output_name))
                success_dsdk = 0
                sys.exit()
            else:
                self.tempVars_dsdk['output_name'] = output_name
            
             if len(placement_identifier) >0:
                 self.tempVars_dsdk['placement_identifier'] = placement_identifier
            
            if len(tag_id) >0:
                self.tempVars_dsdk['tag_id'] = tag_id

            if len(conversion_type_code)>0:
                self.tempVars_dsdk['conversion_type_code'] =conversion_type_code
            
            #custom segment file
            if len(file_name) >0:
                
                appendix_folder = os.path.join(self.dir_path,'appendix')
                
                if file_name not in os.listdir(appendix_folder):
                    print("Cannot locate {} in appendix folder".format(file_name))
                    success_dsdk = 0
                    sys.exit(2)
                else:
                    self.tempVars_dsdk['group_by_name'] = group_by_name
                    self.tempVars_dsdk['segment_name'] = segment_name
                    os.chdir(appendix_folder)
                    self.tempVars_dsdk['custom_segment_dict']= convertAppendixToDict(file_name,group_by_name,segment_name)
                    self.tempVars_dsdk['custom_segment_list']= convertDictTOList(self.tempVars_dsdk['custom_segment_dict'],self.tempVars_dsdk['group_by_name'])
                    
        
        else:
            print('Wrong json file, please check!')
            sys.exit(2)
        
#%%
    def get_dsdk_query(self):
        
        
        file_loader = jinja2.FileSystemLoader(os.path.join(self.dir_path,'template'))
        env = jinja2.Environment(loader = file_loader)
        try:
            template = env.get_template(self.tempVars_dsdk['template_name'])
            self.query = template.render(self.tempVars_dsdk)
            
            if len(self.tempVars_dsdk['output_name']) == 0:
                print ("\nPlease give a name for the result query under 'Saveas' in you {} file\n".format(self.json_path))
                sys.exit(2)
            if writeFile(self.tempVars_dsdk['output_name'],self.query,path) != 1:
                print ("\nFailed to output the SQL query\n")
                sys.exit(2)
            print ("\n {} has been produced!\n".format(self.tempVars_dsdk['output_name']))
            return self.query
        except:
            print("Can't locate template file, please check")
#%%
    def export_query(self,output_query):
        
        if output_query not in os.listdir(os.path.join(self.dir_path,'query')):
            if writeFile(output_query,self.query,self.dir_path) != 1:
                print("/n Failed to output the SQL query\n")
                sys.exit(2)
            
            
            
#%%
    def js_load_paras(self):
        
        if 'jumpshot' in self.json_path:
            
            global success_js
            success_js = 1
            dir_path = os.path.dirname(os.path.dirname(self.json_path))
            
            
            if not checkDatePattern(self.paras['params']['dates']['start']) and checkDatePattern(self.paras['params']['dates']['end']):
                print("Please check start/end date value and format(yyyy-mm-dd)")
                success_js = 0
                sys.exit(2)
            
            else:
                self.tempVars_js['start_date'] =self.paras['params']['dates']['start']
                self.tempVars_js['end_date'] = self.paras['params']['date']['end']
            
            if self.paras['params']['pathInfo']['templateName'] not in os.listdir(os.path.join(dir_path))
            template_name = self.paras['params']['pathInfo']['templateName']
            output_name = self.paras['params']['pathInfo']['templateName']
            
            domain = self.paras['params'][]
            
    
        
        
        