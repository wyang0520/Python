# -*- coding: utf-8 -*-

import sqlalchemy as sql
import pandas as pd
import json
import sys
from pathlib import Path
import re
from datetime import datetime
import os
#%%

#function to connect database
def connect_database(database_name):
    os.chdir("..")
    path = os.getcwd()
    #path to database credential (absolute address)
    db_credential = os.path.join(path+'\\database_credentials','rqt-config.json')
    
    #open and read json file
    try:
        with open(db_credential) as file:
            rqt_config = json.load(file)
    except:
        print ("Database Credential json file doesn't exist")
        sys.exit(2)
    
    #extract credential from json
    try:
        if database_name =='dsdk':
            username = rqt_config['connections']['default']['user']
            password = rqt_config['connections']['default']['password']
            server = rqt_config['connections']['default']['server']
            port = rqt_config['connections']['default']['port']
            database = rqt_config['connections']['default']['database']
        else:
            username = rqt_config['connections'][database_name]['user']
            password = rqt_config['connections'][database_name]['password']
            server = rqt_config['connections'][database_name]['server']
            port = rqt_config['connections'][database_name]['port']
            database = rqt_config['connections'][database_name]['database']
    
    except:
        print ('{} credential does not exist in json file'.format(database_name))
        sys.exit(2)
        
    #database url
    url = "postgresql://{}:{}@{}:{}/{}".format(username,password,server,port,database)
    
    #database engine
    engine = sql.create_engine(url)
    
    #database connection
    conn = engine.connect()
    
    print("Connect to {} successfully".format(database_name))
    return conn


#%%

#function to run query and return dataframe
def get_df(query_path,conn):
    
    try:
        query = Path(query_path).read_text()
    except:
        print("Can't locate {}".format(query_path))
        sys.exit(2)
    
    try:
        df = pd.DataFrame(conn.execute(query))
        return df
    except:
        print("Query execution error, please check your query")
        sys.exit(2)
        
#%%

def AddQuoteToString(string):
    return ",".join(set(map(lambda x: "'"+x+"'", string.split(","))))

#%%

def checkDatePattern(date):
    pattern = '^(\d){4}-(\d){2}-(\d){2}$'
    return bool(re.match(pattern, date))

#%%
def nextMonth(date):
    year,month = divmod(date.month+1,12)
    
    if month == 0:
        month = 12
        year = year - 1
    return datetime(date.year + year, month, 1)


#%%

def getMonthList(startdate, enddate):
    
    start = datetime.strptime(startdate,'%Y-%m-%d')
    end = nextMonth(datetime.strptime(enddate, '%Y-%m-%d'))
    
    months = []
    
    while start < end:
        months.append(start.strftime("%Y_%m"))
        start = nextMonth(start)
    return months
#%%
    
def check_column_header(df,group_by_name, segment_name):
    group_by_name_check = 0
    segment_name_check = 0
    
    for column in df.columns:
        if column.lower() == group_by_name.lower():
            group_by_name_check =+1
        elif column.lower() == segment_name.lower():
            segment_name_check =+1
        else:
            continue
    
    return group_by_name_check>0 and segment_name_check >0
#%%
def convertAppendixToDict(appendix_file,group_by_name,segment_name):
    
    appendix_df = pd.read_csv(appendix_file)
    
    if check_column_header(appendix_df,group_by_name,segment_name):
        output_dict = {}
        appendix_df.columns = map(str.lower, appendix_df.columns)
        for unique_segment in appendix_df[segment_name].unique():
            output_dict[unique_segment] = set(appendix_df[appendix_df[segment_name.lower()]==unique_segment][group_by_name.lower()].drop_duplicates())
       
        return output_dict
    else:
        print("Can't find {} or {} in {}".format([group_by_name,segment_name,appendix_file]))
        
        
#%%
def convertDictTOList(custom_dict, group_by_name):
    
    output = []
    for key in custom_dict:
        string = 'WHEN '+group_by_name+" IN "+ str(custom_dict[key]).replace("{","(").replace("}",")")+" then '"+key+"'"
        output.append(string)
    return output

#%%
def writeFile(filename,content,input_path):
    
    output_path = os.path.join(input_path,'query')
    os.chdir(output_path)
    try:
        with open(filename,'w') as file:
            content_list = content.split("\n")
            for line in content_list:
                if line.strip() !="":
                    file.write(line+'\n')
                else:
                    continue
        return 1
    except:
        return 0


#%%
        
        

        
    
    
    
    