# -*- coding: utf-8 -*-
import sys
import json
import os
from helpfunc import AddQuoteToString, checkDatePattern, getMonthList, nextMonth

os.chdir("..")
path = os.getcwd()



#%%
try:
    json_file = sys.argv[1]
except:
    print ("\n Please provide a json file")
#Json file name

os.chdir(path)

json_file = os.path.join(path+'\\json',json_file)


try:
    with open(json_file) as file:
        paras = json.load(file)
except:
    print('{} does not exist'.format(json_file))
    sys.exit(2)
    
    
#get start date and end date
startdate = paras['params']['dates']['start']
enddate = paras['params']['dates']['end']

#get user input info
campagin_info = paras['params']['campaign_info']['campaigns_by_adserver']

namespace_id = campagin_info[0]['namespace_id']
site_identifier = campagin_info[0]['site_identifier']
campaign_identifier = campagin_info[0]['campaign_identifier']
tag_id = paras['params']['conversion_data']['tag_id']
conversion_type_code= AddQuoteToString(paras['params']['conversion_data']['conversion_type_codes'])

#get any custom grouping info
file_name = paras['params']['custom_segment']['filename']
segment_name = paras['params']['custom_segment']['segment_name']
group_by_name = paras['params']['custom_segment']['groupby']

#template name
query_template_name = paras['params']['pathinfo']['templateName']

#output query name
output_name = paras['params']['pathinfo']['SaveAs']

#Set up global variable
global success
success = 1

#dict variable to store user input
tempVars = {}


#Check date format and create a list contains YYYY_MM
if not checkDatePattern(startdate) and checkDatePattern(enddate):
    print("Please check start/end date value and format(yyyy-mm-dd)")
    
    #break process
    success = 0
    sys.exit(2)
    
else:
    tempVars['start_date'] = startdate
    tempVars['end_date'] = enddate
    tempVars['month_list'] = getMonthList(startdate,enddate)

tempVars['campaign_identifier'] = campaign_identifier
tempVars['site_identifier'] = site_identifier


if len(tag_id) >0:
    tempVars['tag_id'] = tag_id
    
if len(conversion_type_code)>0:
    tempVars['conversion_type_code'] = conversion_type_code
    
#check for custom segment file
if len(file_name) >0:
    appendix_folder = os.path.join(path,'appendix')