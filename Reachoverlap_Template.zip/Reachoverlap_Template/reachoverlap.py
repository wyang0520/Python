#import modules

import pandas as pd
import numpy as np
import os
from pandas import ExcelWriter
import sys

#set up variables
input_file = 'flonase_base_02.csv'

#set path variables
main_path = os.getcwd()
source_path = os.path.join(main_path, 'source')
output_path = os.path.join(main_path, 'output')

#write a function that adds grouping column to the raw_dataset
def processCol(df):
    #get the column first
    col = df.columns[:-1]
    #Get a list of flags
    flags = [list(df.iloc[i,:-1])for i in range(df.shape[0])]
    #prepare for output
    output = []
    #loop through the flags
    for f in flags:
        output.append("|".join([c for c, i in zip(col, f) if i > 0]))
    return output

#create a function that creates an Empty DataFrame with the desired columns
def create_overlap_df(columns):
    new_df = pd.DataFrame(
        data= np.arange(len(columns)**2).reshape(len(columns), len(columns)),
        index=columns,
        columns=columns
    )
    return new_df

#write a function that calculates reach count based on the sites provided
def calculate_reach(row, col, df):
    #prepare output
    reach = 0
    #loop through the dataframe for numbers
    if row == col:
        for uu, name in zip(df.uu, df.grouping):
            if name == row:
                reach += uu
            else:
                continue
    else:
        for uu, name in zip(df.uu, df.grouping):
            if row in name.split('|') and col in name.split('|'):
                reach += uu
            else:
                continue
    #return reach count
    return reach

#create a function that calcualtes the overlap count for each site combo
def configure_df(new_df, old_df):
    #make a copy of the new dataframe
    df_result = new_df.copy()

    #loop through df and do something
    for r in range(0,df_result.shape[0]):
        for c in range(0, df_result.shape[1]):
            #set value for the cell
            df_result.iloc[r,c] = calculate_reach(df_result.index[r], df_result.columns[c], old_df)

    #return result
    return df_result

#create a function that loops through the columns / site and calculate the total reach for each
def calculate_total_reach(col, df):
    #prepare output
    reach = 0
    #loop through the dataframe for numbers
    for uu, name in zip(df.uu, df.grouping):
        if col in name.split('|'):
            reach += uu
        else:
            continue
    #return reach count
    return reach

#create a function that turn the new dataframe into reach %
def create_reach_pct(df, group_total):
    #clone the input dataframe
    new_df = df.copy()

    #Loop through each column and divide values in the column by the column total
    for c in new_df.columns:
        new_df[c] = new_df[c] * 1.0 / group_total[c]

    #return new data frame
    return new_df

#create a function that creates a dataframe of just group totals
def create_total_df(columns, group_total):
    #Get a list of grouping totals
    total_row = []
    total_row.append([group_total[c] for c in columns])

    #turn it into a dataframe and return result
    return pd.DataFrame(total_row, columns=columns, index=['Totals'])

#write a function that outputs the result
def output_result(data, names, output_name, output_path=output_path):
    #open up Excel writer
    writer = ExcelWriter(os.path.join(output_path, output_name))
    #now loop through the data list and output the result into the same spreadsheet
    for d, n in zip(data, names):
        if n == 'Raw_data':
            d.to_excel(writer, sheet_name = n, index=False)
        else:
            d.to_excel(writer, sheet_name = n, index=True)
        #save the workbook
    writer.save()
    #signal progress
    print '%s has been produced!' % output_name


#main function
def main(input_file=input_file, main_path = main_path, source_path = source_path, output_path = output_path):

    #consume the input_file and turn it into a dataframe
    try:
        df_main = pd.read_csv(os.path.join(source_path, input_file))
    except:
        print "\nCannot process %s\n" % input_file
        sys.exit(2)

    #Add grouping column to the input df
    df_main['grouping'] = processCol(df_main)

    #create an empty dataframe with desired columns
    column_header = df_main.columns[:-2]
    df_new = create_overlap_df(column_header)

    #calculate reach count for the new df
    df_new = configure_df(df_new, df_main)

    #Get the total reach for each column / group
    group_total = {}
    for c in column_header:
        group_total[c] = calculate_total_reach(c,df_main)

    #Get a dataframe that has the reach %
    df_new_pct = create_reach_pct(df_new, group_total)
    #clean up any missing values
    df_new_pct = df_new_pct.fillna(0)

    #Get a dataframe of totals
    df_totals = create_total_df(df_new.columns, group_total)

    #Append the total row onto the new df
    new_df_final= df_new.copy()
    new_df_final= df_totals.append(new_df_final, ignore_index=False)

    #output the result
    dfs = [df_new_pct, new_df_final, df_main] #get all the dataframes that need to be output
    names = ['ReachOverlap_Pct','ReachOverlap_Count','Raw_data'] #get all the sheet names
    outputname = os.path.splitext(input_file)[0]+'.xlsx'
    output_result(dfs, names, outputname)


#call main
main()
















