# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 11:49:14 2019

@author: Wenzhao.Yang
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
%matplotlib inline

#read data
df_train = pd.read_csv('train.csv')

df_train.columns

"""
Create an Excel spreadsheet with the following columns:

Variable - Variable name.
Type - Identification of the variables' type: 'numerical' or 'categorical'
Segment - Identification of the variables' segment.
Expectation - Our expectation about the variable influence in "Response" Variable
Conclusion - Our conclusions about the importance of the variable
Comments - Any general comments that occured to us.

"""

#Analyzing Response Variable
df_train['SalePrice'].describe()


#histogram
sns.distplot(df_train['SalePrice'])
#Deviate from the normal distribution
#Skew to left
#Median < Mean


df_train.SalePrice.median()
print("Skewness: %f" %df_train['SalePrice'].skew())
print("Kurtosis: %f" %df_train['SalePrice'].kurt())
#data is highly positive skewed with high kurtosis
#scatter of x/y

#check the relationship bewteen GrlivArea and SalePrice

#scatter plot grlivarea/saleprice
var = 'GrLivArea'
data = pd.concat([df_train['SalePrice'], df_train[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000))
#Linear relationship

#check the relationship between TotalBsmtSF annd SalePrice

#scatter plot grlivarea/saleprice
var = 'TotalBsmtSF'
data = pd.concat([df_train['SalePrice'], df_train[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000))
#strong linear relationship (exponential?)

#check the relationship between OverallQual with SalePrice (Categorical Variable)
var = 'OverallQual'
data = pd.concat([df_train['SalePrice'],df_train[var]], axis = 1)
f, ax = plt.subplots(figsize=(8, 6))
fig = sns.boxplot(x=var, y="SalePrice", data=data)
fig.axis(ymin=0, ymax=800000)
#Higher Qual, higher price

#check the relationship betwen YearBuilt with SalcePrice
var = 'YearBuilt'
data = pd.concat([df_train['SalePrice'],df_train[var]],axis = 1)
f, ax =plt.subplots(figsize = (16,8))
fig = sns.boxplot(x=var, y='SalePrice', data = data)
fig.axis(ymin=0, ymax = 800000)
#no strong relationship


#GrLivArea and TotalBsmtSF have strong linear positive relationship with SalePrice, TotalBsmtSF has very strong linear relationship
#OverQual has strong relationship with SalePrice, where YearBuilt has weak relationship

#Checkt Correlation Matrix
corrmat = df_train.corr()
f,ax = plt.subplots(figsize=(12,9))
sns.heatmap(corrmat,vmax=.8, square = True)

#check top 10 correlation variables of SalePrice

k = 10 #number of variables for heatmap
cols = corrmat.nlargest(k,'SalePrice')['SalePrice'].index
cm = np.corrcoef(df_train[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, yticklabels=cols.values, xticklabels=cols.values)
plt.show()

#scatterplot
sns.set()

cols = ['SalePrice', 'OverallQual', 'GrLivArea', 'GarageCars', 'TotalBsmtSF', 'FullBath', 'YearBuilt']

sns.pairplot(df_train[cols], size = 2)
plt.show()


#missing data
total = df_train.isnull().sum().sort_values(ascending = False)
percent = (df_train.isnull().sum()/df_train.isnull().count()).sort_values(ascending = False)
missing_data = pd.concat([total,percent],axis = 1, keys = ['Total','Percent'])
missing_data.head()

#delete data with missing fields
df_train.drop((missing_data[missing_data['Total'] > 1]).index, 1, inplace = True)
df_train.drop(df_train.loc[df_train['Electrical'].isnull()].index, inplace = True)

df_train.isnull().sum().max()


#outliers

#standardizing data
saleprice_scaled =StandardScaler().fit_transform(df_train['SalePrice'][:,np.newaxis])
low_range = saleprice_scaled[saleprice_scaled[:,0].argsort()][:10]
high_range = saleprice_scaled[saleprice_scaled[:,0].argsort()][-10:]
print('outer range (low) of the distribution:')
print(low_range)
print('\nouter range (high) of the distribution:')
print(high_range)
#low range values are similar and not too far from 0
#High range values are far from 0

#Move on without consider any of those values are outliers

#Bivariate analysis
#bivariate analysis saleprice/grlivarea
var = 'GrLivArea'
data = pd.concat([df_train['SalePrice'], df_train[var]], axis=1)
data.plot.scatter(x=var, y='SalePrice', ylim=(0,800000));

#two observations need to remove

#deleting points
df_train.sort_values(by='GrLivArea', ascending = False)[:2]
df_train = df_train.drop(df_train[df_train['Id'] == 1299].index)
df_train = df_train.drop(df_train[df_train['Id'] == 524].index)

#bivariate analysis TotalBsmtSF and saleprice
var = 'TotalBsmtSF'
data = pd.concat([df_train['SalePrice'], df_train[var]], axis = 1)
data.plot.scatter(x=var,y='SalePrice',ylim = (0,800000))
#no points need to be deleted

#Four assumptions to check: Normality, Homosecdasticity, Linearity, Absence of corrlated erros 

#Check for Normality
sns.distplot(df_train['SalePrice'], fit = norm)
fig = plt.figure()
res = stats.probplot(df_train['SalePrice'],plot = plt)
#not normal, need to do some data transform

#apply log transformation
df_train['SalePrice'] = np.log(df_train['SalePrice'])
#transformed historgram and normal probablity plot
sns.distplot(df_train['SalePrice'], fit = norm)
fig = plt.figure()
res = stats.probplot(df_train['SalePrice'], plot = plt)

#check GrLivArea
sns.distplot(df_train['GrLivArea'],fit = norm)
fig = plt.figure()
res = stats.probplot(df_train['GrLivArea'], plot = plt)

#Apply log transformation
df_train['GrLivArea'] = np.log(df_train['GrLivArea'])
sns.distplot(df_train['GrLivArea'], fit = norm)
fig = plt.figure()
res = stats.probplot(df_train['GrLivArea'], plot = plt)

#check TotalBsmtSF
sns.distplot(df_train['TotalBsmtSF'],fit = norm)
fig = plt.figure()
res = stats.probplot(df_train['TotalBsmtSF'], plot = plt)

#there are sizable obersvations with value 0
#need to add one columne to indicate non-zero and zero observations

#create column for new variable
#if area > 0 then 1 else 0
df_train['HasBsmt'] = pd.Series(len(df_train['TotalBsmtSF']), index = df_train.index)
df_train['HasBsmt'] = 0
df_train.loc[df_train['TotalBsmtSF']>0, 'HasBsmt'] = 1

#transform data 
df_train.loc[df_train['HasBsmt'] == 1, 'TotalBsmtSF'] = np.log(df_train['TotalBsmtSF'])

sns.distplot(df_train[df_train['HasBsmt'] == 1]['TotalBsmtSF'], fit = norm)
fig = plt.figure()
res = stats.probplot(df_train[df_train['HasBsmt'] == 1]['TotalBsmtSF'], plot = plt)


#check for Homosecdasticity
var = 'GrLivArea'
plt.scatter(df_train[var],df_train['SalePrice']) 


var = 'TotalBsmtSF'
plt.scatter(df_train[df_train[var]>0][var],df_train[df_train[var]>0]['SalePrice'])

#Homosecdasticity looks good

#create dummy variables

df_train = pd.get_dummies(df_train)

df_train.columns
