source /home/wenzhaoy/activeConda.sh && source activate databasegraber && cd /home/wenzhaoy/Dashboard_Automation_System && python run.py > /home/wenzhaoy/Dashboard_Automation_System/checkWork.txt 2>&1

