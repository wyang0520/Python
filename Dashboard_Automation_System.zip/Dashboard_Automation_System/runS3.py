import os, sys
sys.path.append(os.getcwd())

from MyLibrary import DataReformat as DR, RedshiftPandaWithS3 as RP
from Configs import config
import pandas as pd
import time
databaseSecret = 'Secrets/database_secret.json'
awsSecret = 'Secrets/s3_credential.json'
databaseStatusUpdate = []
statusTableName = config.StatusUpdateTable
archiveFolder = config.archiveSuccessFolder
for eachConfigFile in config.configLoad:
    dataConfig = eachConfigFile.dataConfig
    for eachDatabase in dataConfig.keys():
        databaseConfig = dataConfig[eachDatabase]
        finishDF = DR.reformatData(databaseConfig, moveFileToFolder=archiveFolder)
        if finishDF is not None:
            unit_testRedshift = RP.RedshiftPandaS3(databaseSecret, config.uploadDatabase, awsSecret)
            try:
                if "upsertBaseColumn" in databaseConfig.keys():
                    if databaseConfig["upsertBaseColumn"]:
                        finishDF = unit_testRedshift.cleanDataFrameColumns(finishDF)
                        unit_testRedshift.s3Upsert(finishDF, eachDatabase, uniqueCol=databaseConfig["upsertBaseColumn"])
                else:
                    unit_testRedshift.s3Upsert(finishDF, eachDatabase)
                currentDatabase = [eachDatabase, True, time.time()]
            except:
                currentDatabase = [eachDatabase, False, time.time()]
            databaseStatusUpdate.append(currentDatabase)
if len(databaseStatusUpdate) > 0:
    databaseStatusDF = pd.DataFrame(databaseStatusUpdate, columns=["database", "success", "timestamp"])
    unit_testRedshift.pandasUpsert(databaseStatusDF, statusTableName, uniqueCol="database")