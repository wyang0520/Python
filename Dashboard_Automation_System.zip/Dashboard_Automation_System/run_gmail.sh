source /home/wenzhaoy/activeConda.sh && source activate databasegraber && cd /home/wenzhaoy/Dashboard_Automation_System && python runGmail.py
