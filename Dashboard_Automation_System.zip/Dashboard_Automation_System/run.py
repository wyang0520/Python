import os, sys
sys.path.append(os.getcwd())

from MyLibrary import DataReformat as DR, RedshiftPanda as RP
from Configs import config
import Configs.SEODashboardConfig as sampleConfig
import pandas as pd
import time
databaseSecret = 'Secrets/database_secret.json'
databaseStatusUpdate = []
statusTableName = config.StatusUpdateTable
archiveFolder = config.archiveSuccessFolder
for eachConfigFile in config.configLoad:
    dataConfig = eachConfigFile.dataConfig
    for eachDatabase in dataConfig.keys():
        databaseConfig = dataConfig[eachDatabase]
        finishDF = DR.reformatData(databaseConfig, moveFileToFolder=archiveFolder)
        if finishDF is not None:
            unit_testRedshift = RP.RedshiftPanda(databaseSecret, config.uploadDatabase)
            try:
                if "upsertBaseColumn" in databaseConfig.keys():
                    if databaseConfig["upsertBaseColumn"]:
                        finishDF = unit_testRedshift.cleanDataFrameColumns(finishDF)
                        unit_testRedshift.pandasUpsert(finishDF, eachDatabase, uniqueCol=databaseConfig["upsertBaseColumn"], showProgress=config.showProgressBar)
                else:
                    unit_testRedshift.pandasUpsert(finishDF, eachDatabase, showProgress=config.showProgressBar)
                currentDatabase = [eachDatabase, True, time.time()]
            except:
                currentDatabase = [eachDatabase, False, time.time()]
            databaseStatusUpdate.append(currentDatabase)
if len(databaseStatusUpdate) > 0:
    databaseStatusDF = pd.DataFrame(databaseStatusUpdate, columns=["database", "success", "timestamp"])
    unit_testRedshift.pandasUpsert(databaseStatusDF, statusTableName, uniqueCol="database", chunkUpload=False, showProgress=config.showProgressBar)