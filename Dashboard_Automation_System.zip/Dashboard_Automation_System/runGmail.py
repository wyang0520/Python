import os, sys
sys.path.append(os.getcwd())

from MyLibrary.GmailAPI import GmailApi
import MyLibrary.NetworkUtil as NU
import Configs.config as fullConfig


CLIENT_SECRET_FILE = 'Secrets/client_secret.json'

def loopThroughConfigs(config, emailInfo):
    for eachConfig in config.configLoad:
        theGmailConfig = eachConfig.gmailConfig
        for eachFolder in theGmailConfig.keys():
            if all(subjectCheck in emailInfo["Subject"] for subjectCheck in theGmailConfig[eachFolder]["subjectContains"]):
                if len(theGmailConfig[eachFolder]["senderAuthorization"]) == 0 or all(sender in emailInfo["Sender"] for sender in theGmailConfig[eachFolder]["senderAuthorization"]):
                    if len(theGmailConfig[eachFolder]["ifLinkContains"]) == 0:
                        try:
                            downloadAttachment = myGmailApi.GetAttachments(each["id"], eachFolder)
                        except:
                            return False
                    else:
                        messageBody = emailInfo["Message_body"]
                        messageBodyLink = getInfo["Message_body_link"]
                        findLinkInLinkArr = False
                        for eachLink in messageBodyLink:
                            if all(subLinkContains in eachLink for subLinkContains in theGmailConfig[eachFolder]["ifLinkContains"]) and "http" in eachLink:
                                fixUrl = NU.fixUrlEscape(eachLink)
                                finalUrl = NU.getFinalRedirectUrl(fixUrl)
                                findLinkInLinkArr = True
                                NU.downloadFile(finalUrl, directory=eachFolder, setExtention=".csv")
                        if not findLinkInLinkArr:
                            if isinstance(messageBody, list):
                                for eachBody in messageBody:
                                    messageBodyArray = eachBody.split("\r\n")
                                    messageArray = list(map(lambda x: x.strip(), messageBodyArray))
                                    for eachString in messageArray:
                                        if all(subLinkContains in eachString for subLinkContains in theGmailConfig[eachFolder]["ifLinkContains"]) and "http" in eachString:
                                            fixUrl = NU.fixUrlEscape(eachString)
                                            finalUrl = NU.getFinalRedirectUrl(fixUrl)
                                            NU.downloadFile(finalUrl, directory=eachFolder, setExtention=".csv")
                            if isinstance(messageBody, str):
                                messageBodyArray = eachBody.split("\r\n")
                                messageArray = list(map(lambda x: x.strip(), messageBodyArray))
                                for eachString in messageArray:
                                    if all(subLinkContains in eachString for subLinkContains in theGmailConfig[eachFolder]["ifLinkContains"]) and "http" in eachString:
                                        fixUrl = NU.fixUrlEscape(eachString)
                                        finalUrl = NU.getFinalRedirectUrl(fixUrl)
                                        NU.downloadFile(finalUrl, directory=eachFolder, setExtention=".csv")
                    return True
    return True

myGmailApi = GmailApi(CLIENT_SECRET_FILE, storeCredentialName="vwtier1gmail.json")
mail_list = myGmailApi.ListMessagesWithLabels()
path, filename = os.path.split(__file__)
for each in mail_list:
    getInfo = myGmailApi.GetMessage(msg_id=each["id"])
    downloadResult = loopThroughConfigs(fullConfig, getInfo)
    if downloadResult:
        myGmailApi.RemoveMessageLabel(each["id"])


