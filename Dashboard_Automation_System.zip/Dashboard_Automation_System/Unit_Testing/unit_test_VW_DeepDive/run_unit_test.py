import os, sys
sys.path.append(os.getcwd())
import time
from MyLibrary import DataReformat as DR, RedshiftPanda as RP

import Configs.VWDeepDiveDashboardConfig as sampleConfig
import pandas as pd

# Try print dataconfig and gmailconfig
print("===================== Print Configurations \r\n")
print(sampleConfig.dataConfig)
print(sampleConfig.gmailConfig)
print("===================== \r\n")

print("===================== Try apply config to create dataframe \r\n")
dataConfig = sampleConfig.dataConfig
for eachDatabase in dataConfig.keys():
    databaseConfig = dataConfig[eachDatabase]
    finishDF = DR.reformatData(databaseConfig)
    path, filename = os.path.split(__file__)
    unit_testRedshift = RP.RedshiftPanda("", "", True)
    if finishDF is not None:
        if "upsertBaseColumn" in databaseConfig.keys():
            if databaseConfig["upsertBaseColumn"]:
                finishDF = unit_testRedshift.cleanDataFrameColumns(finishDF)
                print(finishDF.head())
                unit_testRedshift.pandasUpsert(finishDF, eachDatabase, uniqueCol=databaseConfig["upsertBaseColumn"])
        else:
            unit_testRedshift.pandasUpsert(finishDF, eachDatabase)
        finishDF.to_csv(path + "/result/unit_test_" + eachDatabase + "_" + str(int(time.time())) + ".csv", index=False)
print("===================== \r\n")

