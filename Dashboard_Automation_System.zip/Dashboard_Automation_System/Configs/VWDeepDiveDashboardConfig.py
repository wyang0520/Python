'''PLEASE READ!!!: data reformat configuration
'Rows': 
    checkColumns: Int; Check to see if the column has value; if not flag
    checkColumnLength: Int; Check to see if the column has this many columns; if not flag
    convertToIntColumns: [Int]; Convert values in these columns to Integer; If error stop the function
    convertToFloatColumns: [Int]; Convert values in these columns to Float; If error stop the function
    convertToIntPassColumns: [Int]; Convert values in these columns to Integer; If error use preset value and continue
    convertToFloatPassColumns: [Int]; Convert values in these columns to Float; If error use preset value and continue
    convertToIntColumnsWithPreset: Int; Preset value for convert value to Int;
    convertToFloatColumnsWithPreset: Int; Preset value for convert value to Float;
    hasHeader: Bool; if the csv file has header row at the beginning
    stopWhenCheckColumnNoValue: Bool; if any flag raised, stop readding the file and export;
    includeHashId: Bool; This is optional, the default value is True. This will, if true, include hashid column in the result;
    includeCsvFileName: Bool; This is optional, the default value is False. This will, if true, include csvFileName column in the result;
'Columns':
    key: value ; Column definition. Key(String), Value(String | Dictionary)
    The key will be columns in the export dataFrame no duplicates
    If the value is String:
        if the value string is a column in the original file, map original column into new dataframe
        if the value string is not a column, use it as a fix value
    if the value is Dictionary:
        if { 'fix': value }, set the column to a fix value
        if { 
            ('oriColumn': run function based on original column) 
            ('newColumn': run function based on new column defined ahead)
            'function': definedFunction
           }
    if key "MapAllExcept" has apply, it will always run first. And then the rest will apply. 
    "MapAllExcept": [columnNames], this will automatically create a mapping for all columns except columns in the array.
        Leave "MapAllExcept": [] if you want all columns to be mapped
****** IMPORTANT !!!! *****************
definedFunction need to be set in the front before using it. definedFunction should have only one parameter and must return one result
if the fileFormat set to csv
    The configuration file must include 'Rows'
    All 'Rows' entry points are needed. 

if the fileFormat set to excel
    Function will ignore 'Rows' and only use 'Columns'
    if 'Columns' not set, it will return as is.
    Notice that the dataframe will include additional "file" and "sheetName" columns
        before running 'Columns'

"upsertBaseColumn": "date"
**************************************

'''

# File Modification Config for files in the same folder
dbm_data = {
            "Rows": {
                "checkColumn": 3,
                "checkColumnLength": 8,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [-1],
                "convertToFloatPassColumns": [-2, -3, -4],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

oath_data = {
            "Rows": {
                "checkColumn": 1,
                "checkColumnLength": 7,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [-1],
                "convertToFloatPassColumns": [-2],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

ttd_data = {
            "Rows": {
                "checkColumn": 1,
                "checkColumnLength": 5,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [3],
                "convertToFloatPassColumns": [4],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

sizmek_data = {
            "Rows": {
                "checkColumn": 3,
                "checkColumnLength": 39,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [(3, 38)],
                "convertToFloatPassColumns": [],    
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

dv_data = {
            "Rows": {
                "checkColumn": 1,
                "checkColumnLength": 7,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [3, 4, 5, 6],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }   
}

aap_data = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 6,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [-1],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

xander_data = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 4,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [-1],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

facebook_data = {
            "Rows": {
                "checkColumn": 8,
                "checkColumnLength": 55,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [(8, 54)],
                "convertToFloatPassColumns": [7],
                "convertToIntColumnsWithPreset": 0,
                "convertToFloatColumnsWithPreset": 0.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

sa360_data = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 24,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [15,16],
                "convertToFloatPassColumns": [13,14,17,18,19,21,22,23],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}

search_sizmek_test_data = {
            "Rows": {
                "checkColumn": 2,
                "checkColumnLength": 9,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": False, #Optional
                "includeCsvFileName": False #Optional
            }
}


# Database configs that define folders and its related modification config

dashboard_vw_deepdive_dbm = {
    "dbm_data": {
        "folder": "data/VW_DeepDive/DV360",
        "fileFormat": "csv",
        "cleanAndReFormat": dbm_data
    },
    "concat": ["dbm_data"],
    "upsertBaseColumn": "date"
}

dashboard_vw_deepdive_xander = {
    "xander_data": {
        "folder": "data/VW_DeepDive/Xander",
        "fileFormat": "csv",
        "cleanAndReFormat": xander_data
    },
    "concat": ["xander_data"],
    "upsertBaseColumn": "day"
}


dashboard_vw_deepdive_oath = {
    "oath_data": {
        "folder": "data/VW_DeepDive/OATH",
        "fileFormat": "excel",
        "cleanAndReFormat": oath_data
    },
    "concat": ["oath_data"],
    "upsertBaseColumn": "day"
}

dashboard_vw_deepdive_ttd = {
    "ttd_data": {
        "folder": "data/VW_DeepDive/TTD",
        "fileFormat": "csv",
        "cleanAndReFormat": ttd_data
    },
    "concat": ["ttd_data"],
    "upsertBaseColumn": "date"
}

dashboard_vw_deepdive_sizmek = {
    "sizmek_data": {
        "folder": "data/VW_DeepDive/Sizmek",
        "fileFormat": "csv",
        "cleanAndReFormat": sizmek_data
    },
    "concat": ["sizmek_data"],
    "upsertBaseColumn": "date"
}

dashboard_vw_deepdive_dv = {
    "dv_data": {
        "folder": "data/VW_DeepDive/Viewability",
        "fileFormat": "csv",
        "cleanAndReFormat": dv_data
    },
    "concat": ["dv_data"],
    "upsertBaseColumn": "date"
}

dashboard_vw_deepdive_aap = {
    "aap_data": {
        "folder": "data/VW_DeepDive/AAP",
        "fileFormat": "excel",
        "cleanAndReFormat": aap_data, 
        "onlyReadSheets": ["Campaign"]
    },
    "concat": ["aap_data"],
    "upsertBaseColumn": "date"
}

dashboard_vw_deepdive_facebook = {
    "facebook_data": {
        "folder": "data/VW_DeepDive/Social_Facebook",
        "fileFormat": "csv",
        "cleanAndReFormat":facebook_data
    },
    "concat": ["facebook_data"],
    "upsertBaseColumn": "day"
}

dashboard_vw_deepdive_search_360 = {
    "sa360_data": {
        "folder": "data/VW_DeepDive/Search_360",
        "fileFormat": "excel",
        "cleanAndReFormat":sa360_data
    },
    "concat": ["sa360_data"],
    "upsertBaseColumn": "from"
}

dashboard_vw_deepdive_search_sizmek_test = {
    "search_sizmek_test_data": {
        "folder": "data/VW_DeepDive/Search_Sizmek_Test",
        "fileFormat": "csv",
        "cleanAndReFormat":search_sizmek_test_data
    },
    "concat": ["search_sizmek_test_data"],
    "upsertBaseColumn": "conversion_date"
}

# Define database Name to database config
dataConfig = {
    "dashboard_vw_deepdive_dbm": dashboard_vw_deepdive_dbm,
    "dashboard_vw_deepdive_oath": dashboard_vw_deepdive_oath,
    "dashboard_vw_deepdive_ttd": dashboard_vw_deepdive_ttd,
    "dashboard_vw_deepdive_sizmek": dashboard_vw_deepdive_sizmek,
    "dashboard_vw_deepdive_dv": dashboard_vw_deepdive_dv,
    "dashboard_vw_deepdive_aap": dashboard_vw_deepdive_aap,
    "dashboard_vw_deepdive_facebook": dashboard_vw_deepdive_facebook,
    "dashboard_vw_deepdive_search_360": dashboard_vw_deepdive_search_360,
    "dashboard_vw_deepdive_search_sizmek_test": dashboard_vw_deepdive_search_sizmek_test,
    "dashboard_vw_deepdive_xander": dashboard_vw_deepdive_xander



}

# Define gmail read configuration and folder to save attachment
gmailConfig = {
    "data/VW_DeepDive/OATH": {
        "subjectContains": ["automation", "vw", "Verizon"],
        "senderAuthorization": ["verizonmedia.com"],
        "ifLinkContains": []
    },
    "data/VW_DeepDive/TTD": {
        "subjectContains": ["deepdive", "VW"],
        "senderAuthorization": [],
        "ifLinkContains": ["thetradedesk.com"]
    },
    "data/VW_DeepDive/DV360": {
        "subjectContains": ["Deep_Dive", "VW"],
        "senderAuthorization": ["google.com"],
        "ifLinkContains": []
    },
    "data/VW_DeepDive/Sizmek": {
        "subjectContains": ["Sizmek", "MDX", "WZ_report_t1"],
        "senderAuthorization": ["mediamind.com"],
        "ifLinkContains": []
    },
    "data/VW_DeepDive/Viewability": {
        "subjectContains": ["Viewability", "Blocking"],
        "senderAuthorization": ["doubleverify.com"],
        "ifLinkContains": ["doubleverify.com", "Download"]
    },
    "data/VW_DeepDive/Search_Sizmek_Test": {
        "subjectContains": ["Feed", "Sizmek"],
        "senderAuthorization": ["sizmek.com"],
        "ifLinkContains": []
    },
    "data/VW_DeepDive/Search_360": {
        "subjectContains": ["SA360"],
        "senderAuthorization": ["google.com"],
        "ifLinkContains": []
    },
    "data/VW_DeepDive/Xander": {
        "subjectContains": ["AppNexus", "VW"],
        "senderAuthorization": ["appnexus.com"],
        "ifLinkContains": []
    }
}
