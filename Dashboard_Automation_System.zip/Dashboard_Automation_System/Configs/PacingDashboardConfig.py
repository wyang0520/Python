'''PLEASE READ!!!: data reformat configuration
'Rows': 
    checkColumns: Int; Check to see if the column has value; if not flag
    checkColumnLength: Int; Check to see if the column has this many columns; if not flag
    convertToIntColumns: [Int]; Convert values in these columns to Integer; If error stop the function
    convertToFloatColumns: [Int]; Convert values in these columns to Float; If error stop the function
    convertToIntPassColumns: [Int]; Convert values in these columns to Integer; If error use preset value and continue
    convertToFloatPassColumns: [Int]; Convert values in these columns to Float; If error use preset value and continue
    convertToIntColumnsWithPreset: Int; Preset value for convert value to Int;
    convertToFloatColumnsWithPreset: Int; Preset value for convert value to Float;
    hasHeader: Bool; if the csv file has header row at the beginning
    stopWhenCheckColumnNoValue: Bool; if any flag raised, stop readding the file and export;
    includeHashId: Bool; This is optional, the default value is True. This will, if true, include hashid column in the result;
    includeCsvFileName: Bool; This is optional, the default value is False. This will, if true, include csvFileName column in the result;
'Columns':
    key: value ; Column definition. Key(String), Value(String | Dictionary)
    The key will be columns in the export dataFrame no duplicates
    If the value is String:
        if the value string is a column in the original file, map original column into new dataframe
        if the value string is not a column, use it as a fix value
    if the value is Dictionary:
        if { 'fix': value }, set the column to a fix value
        if { 
            ('oriColumn': run function based on original column) 
            ('newColumn': run function based on new column defined ahead)
            'function': definedFunction
           }

****** IMPORTANT !!!! *****************
definedFunction need to be set in the front before using it. definedFunction should have only one parameter and must return one result
if the fileFormat set to csv
    The configuration file must include 'Rows'
    All 'Rows' entry points are needed. 

if the fileFormat set to excel
    Function will ignore 'Rows' and only use 'Columns'
    if 'Columns' not set, it will return as is.
    Notice that the dataframe will include additional "file" and "sheetName" columns
        before running 'Columns'

**************************************

'''

#Self defined function
import datetime
def DateConvert(x):
    dateArray = x.split("/")
    month = int(dateArray[0])
    day = int(dateArray[1])
    year = int(dateArray[2])
    return datetime.datetime(year, month, day)

def DBMDateConvert(x):
    dateArray = x.split("/")
    month = int(dateArray[1])
    day = int(dateArray[2])
    year = int(dateArray[0])
    return datetime.datetime(year, month, day)

def AAPDateConvert(x):
    dateArray = x.split("-")
    month = int(dateArray[1])
    day = int(dateArray[2])
    year = int(dateArray[0])
    return datetime.datetime(year, month, day)

# File Modification Config for files in the same folder
DBM = {
            "Rows": {
                "checkColumn": 9,
                "checkColumnLength": 12,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [11],
                "convertToFloatPassColumns": [10],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            },
            "Columns": {
                "Date": {
                    "oriColumn": "Date",
                    "function": DBMDateConvert
                }, 
                "Advertiser": "Advertiser", 
                "Advertiser ID": "Advertiser ID",
                "Creative": "Creative",
                "Creative ID": "Creative ID",
                "Line Item": "Creative",
                "Line Item ID": "Creative ID",
                "Insertion Order": "Insertion Order",
                "Insertion Order ID": "Insertion Order ID",
                "Revenue (Adv Currency)": "Revenue (Adv Currency)",
                "Impressions": "Impressions", 
                "Advertiser Currency": "Advertiser Currency", 
                "DSP": {
                    "fix": "DBM"
                }
            }
}

AAP = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 13,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [12],
                "convertToFloatPassColumns": [11],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            },
            "Columns": {
                "Date": "Date",  
                "Advertiser": "Advertiser", 
                "Advertiser ID": "Advertiser ID",
                "Creative": "Creative",
                "Creative ID": "Creative ID",
                "Line Item": "Creative",
                "Line Item ID": "Creative ID",
                "Revenue (Adv Currency)": "Total cost",
                "Impressions": "Impressions",
                "DSP": {
                    "fix": "AAP"
                },
                "Advertiser Currency": {
                    "fix": "USD"
                },
                "Insertion Order": {
                    "fix": "AAP"
                },
                "Insertion Order ID": {
                    "fix": 0
                }
            }
}

OATH = {
            # "Rows": {
            #     "checkColumn": 0,
            #     "checkColumnLength": 14,
            #     "convertToIntColumns": [],
            #     "convertToFloatColumns": [], 
            #     "convertToIntPassColumns": [13],
            #     "convertToFloatPassColumns": [12],
            #     "convertToIntColumnsWithPreset": -5,
            #     "convertToFloatColumnsWithPreset": -5.0,
            #     "hasHeader": True,
            #     "stopWhenCheckColumnNoValue": True,
            #     "includeHashId": True, #Optional
            #     "includeCsvFileName": False  #Optional
            # },
            "Columns": {
                "Date": "Day",  
                "Advertiser": "Advertiser", 
                "Advertiser ID": "Advertiser Id",
                "Creative": "Creative",
                "Creative ID": "Creative Id",
                "Line Item": "Line",
                "Line Item ID": "Line Id",
                "Revenue (Adv Currency)": "Advertiser Spending",
                "Impressions": "Impressions", 
                "DSP": {
                    "fix": "Oath"
                },
                "Advertiser Currency": {
                    "fix": "USD"
                },
                "Insertion Order": {
                    "fix": "Oath"
                },
                "Insertion Order ID": {
                    "fix": 0
                }
            }
}

TTD = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 9,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [8],
                "convertToFloatPassColumns": [7],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            },
            "Columns": {
                "Date": {
                    "oriColumn": "Date",
                    "function": DateConvert
                },  
                "Advertiser": "Advertiser", 
                "Advertiser ID": "Advertiser ID",
                "Creative": "Creative",
                "Creative ID": "Creative ID",
                "Line Item": "Campaign",
                "Line Item ID": "Campaign ID",
                "Revenue (Adv Currency)": "Advertiser Cost (USD)",
                "Impressions": "Impressions", 
                "DSP": {
                    "fix": "TTD"
                },
                "Advertiser Currency": {
                    "fix": "USD"
                },
                "Insertion Order": {
                    "fix": "TTD"
                },
                "Insertion Order ID": {
                    "fix": 0
                }
            }
}

dsp_dcm = {
    "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 2,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            }
}

dcm_prisma = {
    "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 2,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            }
}

dcm_data = {
    "Rows": {
                "checkColumn": 3,
                "checkColumnLength": 5,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [4],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": False,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            }
}

prisma_data = {
    "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 32,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [29, 30],
                "convertToFloatPassColumns": [4, 5, 23, 24, 25, 26, 31],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": True, #Optional
                "includeCsvFileName": False  #Optional
            }
}

# Database configs that define folders and its related modification config

dashboard_pacing_dsp_aggregate = {
    "DBM": {
        "folder": "data/Pacing_Dashboard/DSP_Total/DBM",
        "fileFormat": "csv",
        "cleanAndReFormat": DBM
    },
    "AAP": {
        "folder": "data/Pacing_Dashboard/DSP_Total/AAP",
        "fileFormat": "excel",
        "cleanAndReFormat": AAP,
        "onlyReadSheets": ["Creative"]
    },
    "OATH": {
        "folder": "data/Pacing_Dashboard/DSP_Total/OATH",
        "fileFormat": "excel",
        "cleanAndReFormat": OATH
    },
    "TTD": {
        "folder": "data/Pacing_Dashboard/DSP_Total/TTD",
        "fileFormat": "csv",
        "cleanAndReFormat": TTD
    },
    "concat": ["DBM", "AAP", "OATH", "TTD"],
}

dashboard_pacing_dsp_dcm_matching = {
    "dsp_dcm": {
        "folder": "data/Pacing_Dashboard/DSP_DCM",
        "fileFormat": "csv",
        "cleanAndReFormat": dsp_dcm
    },
    "concat": ["dsp_dcm"],
    "upsertBaseColumn": "creative_id" # Must match the name on the database, not the name on csv
}

dashboard_pacing_dcm_prisma_matching = {
    "dcm_prisma": {
        "folder": "data/Pacing_Dashboard/DCM_Prisma",
        "fileFormat": "csv",
        "cleanAndReFormat": dcm_prisma
    },
    "concat": ["dcm_prisma"]
}

dashboard_pacing_dcm_data = {
    "dcm_data": {
        "folder": "data/Pacing_Dashboard/DCM",
        "fileFormat": "csv",
        "cleanAndReFormat": dcm_data
    },
    "concat": ["dcm_data"]
}

dashboard_pacing_prisma_data = {
    "prisma_data": {
        "folder": "data/Pacing_Dashboard/Prisma",
        "fileFormat": "csv",
        "cleanAndReFormat": prisma_data
    },
    "concat": ["prisma_data"]
}

# Define database Name to database config
dataConfig = {
    "dashboard_pacing_dsp_aggregate": dashboard_pacing_dsp_aggregate,
    "dashboard_pacing_dsp_dcm_matching": dashboard_pacing_dsp_dcm_matching,
    "dashboard_pacing_dcm_prisma_matching": dashboard_pacing_dcm_prisma_matching,
    "dashboard_pacing_dcm_data": dashboard_pacing_dcm_data,
    "dashboard_pacing_prisma_data": dashboard_pacing_prisma_data
}

# Define gmail read configuration and folder to save attachment
gmailConfig = {
    "data/Pacing_Dashboard/DSP_Total/OATH": {
        "subjectContains": ["Pacing", "daily"],
        "senderAuthorization": ["oath.com"],
        "ifLinkContains": []
    },
    "data/Pacing_Dashboard/DSP_Total/TTD": {
        "subjectContains": ["daily", "Pacing"],
        "senderAuthorization": ["thetradedesk.com"],
        "ifLinkContains": ["thetradedesk.com"]
    },
    "data/Pacing_Dashboard/DSP_Total/AAP": {
        "subjectContains": ["GSK"],
        "senderAuthorization": ["amazon.com"],
        "ifLinkContains": []
    },
    "data/Pacing_Dashboard/DSP_Total/DBM": {
        "subjectContains": ["daily", "Pacing"],
        "senderAuthorization": ["google.com"],
        "ifLinkContains": []
    }
}
