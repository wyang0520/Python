def getTypeTw_testfunc(x): 
    return x

'''PLEASE READ!!!: data reformat configuration
'Rows': 
    checkColumns: Int; Check to see if the column has value; if not flag
    checkColumnLength: Int; Check to see if the column has this many columns; if not flag
    convertToIntColumns: [Int]; Convert values in these columns to Integer; If error stop the function
    convertToFloatColumns: [Int]; Convert values in these columns to Float; If error stop the function
    convertToIntPassColumns: [Int]; Convert values in these columns to Integer; If error use preset value and continue
    convertToFloatPassColumns: [Int]; Convert values in these columns to Float; If error use preset value and continue
    convertToIntColumnsWithPreset: Int; Preset value for convert value to Int;
    convertToFloatColumnsWithPreset: Int; Preset value for convert value to Float;
    hasHeader: Bool; if the csv file has header row at the beginning
    stopWhenCheckColumnNoValue: Bool; if any flag raised, stop readding the file and export;
    includeHashId: Bool; This is optional, the default value is True. This will, if true, include hashid column in the result;
    includeCsvFileName: Bool; This is optional, the default value is False. This will, if true, include csvFileName column in the result;
'Columns':
    key: value ; Column definition. Key(String), Value(String | Dictionary)
    The key will be columns in the export dataFrame no duplicates
    If the value is String:
        if the value string is a column in the original file, map original column into new dataframe
        if the value string is not a column, use it as a fix value
    if the value is Dictionary:
        if { 'fix': value }, set the column to a fix value
        if { 
            ('oriColumn': run function based on original column) 
            ('newColumn': run function based on new column defined ahead)
            'function': definedFunction
           }
    if key "MapAllExcept" has apply, it will always run first. And then the rest will apply. 
    "MapAllExcept": [columnNames], this will automatically create a mapping for all columns except columns in the array.
        Leave "MapAllExcept": [] if you want all columns to be mapped
****** IMPORTANT !!!! *****************
definedFunction need to be set in the front before using it. definedFunction should have only one parameter and must return one result
if the fileFormat set to csv
    The configuration file must include 'Rows'
    All 'Rows' entry points are needed. 

if the fileFormat set to excel
    Function will ignore 'Rows' and only use 'Columns'
    if 'Columns' not set, it will return as is.
    Notice that the dataframe will include additional "file" and "sheetName" columns
        before running 'Columns'

**************************************

'''

# File Modification Config for files in the same folder
data1CSV = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 15,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [],
                "convertToFloatPassColumns": [],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True,
                "includeHashId": False, #Optional
                "includeCsvFileName": True  #Optional
            },
            "Columns": {
                "Campaign Name": "Campaign name",
                "Impressions": "Impressions",
                "Amount Spent (USD)": "Spend",
                "Platform": {
                    "fix": "TW"
                },
                "Type": {
                    "oriColumn": "Result Type",
                    "function": getTypeTw_testfunc
                },
                "fileBrand": ["file", " " ,"Campaign Name"]
            }
}

data1Excel = {
            "Columns": {
                "Campaign Name": "Campaign name",
                "Impressions": "Impressions",
                "Amount Spent (USD)": "Spend",
                "Platform": {
                    "fix": "TW"
                },
                "Type": {
                    "oriColumn": "Result Type",
                    "function": getTypeTw_testfunc
                },
                "fileBrand": ["file", " " ,"Campaign Name"]
            }
}

# Database configs that define folders and its related modification config

databaseName = {
    "data1csv": {
        "folder": "",
        "fileFormat": "csv",
        "cleanAndReFormat": data1CSV
    },
    "data1excel": {
        "folder": "",
        "fileFormat": "excel",
        "cleanAndReFormat": data1Excel,
        "readAllSheetsExcept": None # Optional, must be array [], don't set this key or set it to None when don't need
        "onlyReadSheets": None # Optional, must be array [] , don't set this key or set it to None when don't need
    },
    "concat": ["data1csv", "data1excel"],
}

# Define database Name to database config
dataConfig = {
    "databaseName": databaseName
}

# Define gmail read configuration and folder to save attachment
gmailConfig = {
    "folderDirectory": {
        "subjectContains": [],
        "senderAuthorization": [],
        "ifLinkContains": []
    }
}
