'''PLEASE READ!!!: data reformat configuration
'Rows': 
    checkColumns: Int; Check to see if the column has value; if not flag
    checkColumnLength: Int; Check to see if the column has this many columns; if not flag
    convertToIntColumns: [Int]; Convert values in these columns to Integer; If error stop the function
    convertToFloatColumns: [Int]; Convert values in these columns to Float; If error stop the function
    convertToIntPassColumns: [Int]; Convert values in these columns to Integer; If error use preset value and continue
    convertToFloatPassColumns: [Int]; Convert values in these columns to Float; If error use preset value and continue
    convertToIntColumnsWithPreset: Int; Preset value for convert value to Int;
    convertToFloatColumnsWithPreset: Int; Preset value for convert value to Float;
    hasHeader: Bool; if the csv file has header row at the beginning
    stopWhenCheckColumnNoValue: Bool; if any flag raised, stop readding the file and export;

'Columns':
    key: value ; Column definition. Key(String), Value(String | Dictionary)
    The key will be columns in the export dataFrame no duplicates
    If the value is String:
        if the value string is a column in the original file, map original column into new dataframe
        if the value string is not a column, use it as a fix value
    if the value is Dictionary:
        if { 'fix': value }, set the column to a fix value
        if { 
            ('oriColumn': run function based on original column) 
            ('newColumn': run function based on new column defined ahead)
            'function': definedFunction
           }

****** IMPORTANT !!!! *****************
definedFunction need to be set in the front before using it. definedFunction should have only one parameter and must return one result
if the fileFormat set to csv
    The configuration file must include 'Rows'
    All 'Rows' entry points are needed. 

if the fileFormat set to excel
    Function will ignore 'Rows' and only use 'Columns'
    if 'Columns' not set, it will return as is.
    Notice that the dataframe will include additional "file" and "sheetName" columns
        before running 'Columns'

**************************************

'''

dbm_overview = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 16,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [9, 12, 13, 14],
                "convertToFloatPassColumns": [15],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True
            }
}

url_analysis = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 12,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [6, 8, 9, 11],
                "convertToFloatPassColumns": [10],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True
            }
}

TODDOW = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 13,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [5, 9, 10, 11],
                "convertToFloatPassColumns": [12],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True
            }
}

inventory_analysis = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 13,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [5, 7, 9, 10, 12],
                "convertToFloatPassColumns": [11],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True
            }
}

dbm_optimization_dbm_overview = {
    "dbm_overview": {
        "folder": "data/DBM_Optimization/DBM_Overview",
        "fileFormat": "csv",
        "cleanAndReFormat": dbm_overview
    },
    "concat": ["dbm_overview"]
}

dbm_optimization_url_analysis = {
    "url_analysis": {
        "folder": "data/DBM_Optimization/url_analysis",
        "fileFormat": "csv",
        "cleanAndReFormat": url_analysis
    },
    "concat": ["url_analysis"]
}

dbm_optimization_TODDOW = {
    "TODDOW": {
        "folder": "data/DBM_Optimization/TODDOW",
        "fileFormat": "csv",
        "cleanAndReFormat": TODDOW
    },
    "concat": ["TODDOW"]
}

dbm_optimization_inventory_analysis = {
    "inventory_analysis": {
        "folder": "data/DBM_Optimization/inventory_analysis",
        "fileFormat": "csv",
        "cleanAndReFormat": inventory_analysis
    },
    "concat": ["inventory_analysis"]
}

dataConfig = {
    "dashboard_dbm_optimization_url_analysis": dbm_optimization_url_analysis,
    "dashboard_dbm_optimization_toddow": dbm_optimization_TODDOW,
    "dashboard_dbm_optimization_inventory_analysis": dbm_optimization_inventory_analysis,
    "dashboard_dbm_optimization_dbm_overview": dbm_optimization_dbm_overview
    
}

gmailConfig = {
    "data/DBM_Optimization/DBM_Overview": {
        "subjectContains": ["DBM_Overview_Daily"],
        "senderAuthorization": ["Xiangyu Wang", "google.com"],
        "ifLinkContains": []
    },
    "data/DBM_Optimization/url_analysis": {
        "subjectContains": ["url_analysis_daily"],
        "senderAuthorization": ["Xiangyu Wang", "google.com"],
        "ifLinkContains": []
    },
    "data/DBM_Optimization/TODDOW": {
        "subjectContains": ["TODDOW_Daily"],
        "senderAuthorization": ["Xiangyu Wang", "google.com"],
        "ifLinkContains": []
    },
    "data/DBM_Optimization/inventory_analysis": {
        "subjectContains": ["inventory_analysis_daily"],
        "senderAuthorization": ["Xiangyu Wang", "google.com"],
        "ifLinkContains": []
    }
}
