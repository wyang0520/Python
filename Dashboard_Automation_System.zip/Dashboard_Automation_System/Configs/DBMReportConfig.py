'''PLEASE READ!!!: data reformat configuration
'Rows': 
    checkColumns: Int; Check to see if the column has value; if not flag
    checkColumnLength: Int; Check to see if the column has this many columns; if not flag
    convertToIntColumns: [Int]; Convert values in these columns to Integer; If error stop the function
    convertToFloatColumns: [Int]; Convert values in these columns to Float; If error stop the function
    convertToIntPassColumns: [Int]; Convert values in these columns to Integer; If error use preset value and continue
    convertToFloatPassColumns: [Int]; Convert values in these columns to Float; If error use preset value and continue
    convertToIntColumnsWithPreset: Int; Preset value for convert value to Int;
    convertToFloatColumnsWithPreset: Int; Preset value for convert value to Float;
    hasHeader: Bool; if the csv file has header row at the beginning
    stopWhenCheckColumnNoValue: Bool; if any flag raised, stop readding the file and export;

'Columns':
    key: value ; Column definition. Key(String), Value(String | Dictionary)
    The key will be columns in the export dataFrame no duplicates
    If the value is String:
        if the value string is a column in the original file, map original column into new dataframe
        if the value string is not a column, use it as a fix value
    if the value is Dictionary:
        if { 'fix': value }, set the column to a fix value
        if { 
            ('oriColumn': run function based on original column) 
            ('newColumn': run function based on new column defined ahead)
            'function': definedFunction
           }

****** IMPORTANT !!!! *****************
definedFunction need to be set in the front before using it. definedFunction should have only one parameter and must return one result
if the fileFormat set to csv
    The configuration file must include 'Rows'
    All 'Rows' entry points are needed. 

if the fileFormat set to excel
    Function will ignore 'Rows' and only use 'Columns'
    if 'Columns' not set, it will return as is.
    Notice that the dataframe will include additional "file" and "sheetName" columns
        before running 'Columns'

**************************************

'''

dbmUIReportCSV = {
            "Rows": {
                "checkColumn": 0,
                "checkColumnLength": 14,
                "convertToIntColumns": [],
                "convertToFloatColumns": [], 
                "convertToIntPassColumns": [7, 8, 9, 10, 12, 13],
                "convertToFloatPassColumns": [11],
                "convertToIntColumnsWithPreset": -5,
                "convertToFloatColumnsWithPreset": -5.0,
                "hasHeader": True,
                "stopWhenCheckColumnNoValue": True
            }
}


dbm_report_dbm_ui_report = {
    "dbmUIReportCSV": {
        "folder": "data/DBM_Report/DBM_UI_Report",
        "fileFormat": "csv",
        "cleanAndReFormat": dbmUIReportCSV
    },
    "concat": ["dbmUIReportCSV"]
}

dataConfig = {
    "dashboard_dbm_report_dbm_ui_report": dbm_report_dbm_ui_report
}

gmailConfig = {
    "data/DBM_Report/DBM_UI_Report": {
        "subjectContains": ["DBM_UI_Report_Daily"],
        "senderAuthorization": ["Xiangyu Wang", "google.com"],
        "ifLinkContains": []
    }
}
