from . import VWDeepDiveDashboardConfig

configLoad = [
    VWDeepDiveDashboardConfig
]
uploadDatabase = "dt-022"
archiveSuccessFolder = "data/archive"
StatusUpdateTable = "dashboard_overall_status_vw"
showProgressBar = False