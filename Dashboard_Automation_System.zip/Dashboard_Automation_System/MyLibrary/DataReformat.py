from . import MyUtil as MU
import pandas as pd
import os
import shutil

def _cleanCSVRows(csv_file ,csvRowConfig):
    if "includeCsvFileName" in csvRowConfig.keys():
        return MU.extractCsvData(csv_file, csvRowConfig["checkColumn"], csvRowConfig["checkColumnLength"], csvRowConfig["convertToIntColumns"], csvRowConfig["convertToFloatColumns"], csvRowConfig["convertToIntPassColumns"], csvRowConfig["convertToFloatPassColumns"], csvRowConfig["convertToIntColumnsWithPreset"], csvRowConfig["convertToFloatColumnsWithPreset"], csvRowConfig["hasHeader"], csvRowConfig["stopWhenCheckColumnNoValue"], includeCsvFileName=csvRowConfig["includeCsvFileName"])
    return MU.extractCsvData(csv_file, csvRowConfig["checkColumn"], csvRowConfig["checkColumnLength"], csvRowConfig["convertToIntColumns"], csvRowConfig["convertToFloatColumns"], csvRowConfig["convertToIntPassColumns"], csvRowConfig["convertToFloatPassColumns"], csvRowConfig["convertToIntColumnsWithPreset"], csvRowConfig["convertToFloatColumnsWithPreset"], csvRowConfig["hasHeader"], csvRowConfig["stopWhenCheckColumnNoValue"])

# checkFolderEmpty() before running the rest of the code
def checkFolderEmpty(folderDirecotry):
    if len(os.listdir(folderDirecotry)) > 0:
        return True
    else:
        return False

def reformatData(config, moveFileToFolder = None):
    concatDF = []
    assert config["concat"], "Missing 'folder' in the configuration"
    for eachData in config["concat"]:
        if not config[eachData]:
            continue
        readFolder = config[eachData]["folder"]
        print(readFolder)
        cleanAndReformat = config[eachData]["cleanAndReFormat"]
        assert readFolder, eachData + " missing 'folder' in the configuration"
        assert cleanAndReformat, eachData + " missing 'cleanAndReFormat' in the configuration"
        if not checkFolderEmpty(readFolder):
            continue
        if config[eachData]["fileFormat"] == "csv":
            assert cleanAndReformat["Rows"], eachData + "'cleanAndReFormat' is missing 'Rows' for csv file format"
            csvConcat = []
            for eachFile in os.listdir(readFolder):
                if ".csv" not in eachFile:
                    continue
                filePath = os.path.join(readFolder, eachFile)
                (unHashDf, preHashDF) = _cleanCSVRows(filePath, cleanAndReformat["Rows"])
                hashDF = preHashDF
                if "includeHashId" in cleanAndReformat["Rows"].keys():
                    assert isinstance(cleanAndReformat["Rows"]["includeHashId"], bool), eachData + "rows includeHashId must be boolean"
                    if not cleanAndReformat["Rows"]["includeHashId"]:
                        hashDF = unHashDf
                if "Columns" in cleanAndReformat.keys():
                    newDf = MU.dataFrameReformat(hashDF, cleanAndReformat["Columns"])
                    csvConcat.append(newDf)
                else:
                    csvConcat.append(hashDF)
            csvFullDF = pd.concat(csvConcat, sort=False)
            concatDF.append(csvFullDF)
        elif config[eachData]["fileFormat"] == "excel":
            onlyReadSheets = None
            readAllSheetsExcept = None
            if "onlyReadSheets" in config[eachData]:
                onlyReadSheets = config[eachData]["onlyReadSheets"]
            if "readAllSheetsExcept" in config[eachData]:
                readAllSheetsExcept = config[eachData]["readAllSheetsExcept"]
            formatedDF = MU.readExcelConcat(readFolder, onlyReadSheet=onlyReadSheets, readAllSheetsExcept=readAllSheetsExcept)
            if "Columns" in cleanAndReformat.keys():
                concatDF.append(MU.dataFrameReformat(formatedDF, cleanAndReformat["Columns"]))
            else:
                concatDF.append(formatedDF)
    if len(concatDF) == 0:
        return None
    fullDF = pd.concat(concatDF, sort=False)
    if moveFileToFolder:
        for eachData in config["concat"]:
            if not config[eachData]:
                continue
            readFolder = config[eachData]["folder"]
            if not checkFolderEmpty(readFolder):
                continue
            for eachFile in os.listdir(readFolder):
                shutil.move(os.path.join(readFolder, eachFile), moveFileToFolder)
                os.rename(os.path.join(moveFileToFolder,eachFile),os.path.join(moveFileToFolder,MU.changeFileName(eachFile)))

    return fullDF


