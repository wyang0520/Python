import os, sys
sys.path.append(os.getcwd())
from MyLibrary.RedshiftPanda import RedshiftPanda
from MyLibrary.MyS3Library import MyS3
import pandas as pd
import numpy as np
import json
import hashlib, time, os

class RedshiftPandaS3(RedshiftPanda):
    def __init__(self, databaseSecretLocation, databaseName, awsSettingFile, unit_testing = False, throughSSH = False, sshSettingFile = None):
        self.tunnel = None
        if throughSSH and not unit_testing and sshSettingFile is not None:
            super().__init__(databaseSecretLocation, databaseName, unit_testing=True)
            self.unit_testing = False
            try:
                with open(sshSettingFile, 'r') as sshFile:
                    self.theSSHFile = json.load(sshFile)
                    self.sshHost = self.theSSHFile["ssh_host"]
                    self.sshUser = self.theSSHFile["ssh_username"]
                    self.sshPrivateKeyPath = self.theSSHFile["ssh_private_key_location"]
                    self.sshPort = self.theSSHFile["ssh_port"]
            except:
                raise Exception("SSH File reading error, please check the file format")
            self._connectThroughSSHTunnel(databaseSecretLocation, databaseName, self.sshHost, self.sshUser, self.sshPrivateKeyPath, sshPort=self.sshPort)
        else:
            super().__init__(databaseSecretLocation, databaseName, unit_testing=unit_testing)
        with open(awsSettingFile, 'r') as settingFile:
            self.theSettingFile = json.load(settingFile)
            self.awsAccessKey = self.theSettingFile["aws_access_key"]
            self.awsSecretKey = self.theSettingFile["aws_secret_key"]
            self.bucketName = self.theSettingFile["bucket"]
            self.myS3 = MyS3(self.awsAccessKey, self.awsSecretKey)
            self.myS3.connectToBucket(self.bucketName)
            if "region" in self.theSettingFile.keys():
                self.bucketRegion = self.theSettingFile["region"]
            else:
                self.bucketRegion = self.myS3.bucket.get_location()
    
    def tableCreateSqlGenerate(self, dataFrame, tableName, distKeyColumnName = "", convertLargeText = False):
        def checkDistKey(counter, currentKey):
            if (distKeyColumnName == "" and counter == 1) or (distKeyColumnName == currentKey):
                return " DISTKEY"
            else:
                return ""
        getType = dict(dataFrame.dtypes)
        counter = 0
        resultString = ""
        for eachKey in getType.keys():
            if counter != 0:
                resultString += ", "
                counter += 1
            else:
                counter += 1
            if str(getType[eachKey]) == "int64":
                resultString += (str(eachKey) + " REAL ENCODE ZSTD" + checkDistKey(counter, eachKey))
            elif str(getType[eachKey]) == "float64" :
                resultString += (str(eachKey) + " FLOAT ENCODE ZSTD" + checkDistKey(counter, eachKey))
            else:
                if convertLargeText:
                    resultString += (str(eachKey) + " VARCHAR(5000) ENCODE ZSTD" + checkDistKey(counter, eachKey))
                else:
                    resultString += (str(eachKey) + " TEXT ENCODE ZSTD" + checkDistKey(counter, eachKey))
        sqlStart = '''
            CREATE TABLE %s (
                %s
            )
        ''' % (
            tableName, resultString
        )
        return sqlStart
############################ S3 upload method #########################################################


    def copyDataFromS3(self, fileName, tableName, columnListInOrder):
        theTableName = tableName
        if self.bucketRegion == '':
            theRegion = ''
        else:
            theRegion = "region '" + self.bucketRegion + "'"
        theSql = '''
            COPY %s 
            from 's3://%s/%s' 
            CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s' CSV
            %s;
        ''' % (
            theTableName + "(" + ",".join(columnListInOrder) + ")", self.bucketName, fileName, self.awsAccessKey, self.awsSecretKey, theRegion
        )
        return theSql

    def _connectThroughSSHTunnel(self, databaseSecretLocation, databaseName, sshHost, sshUser, sshPrivateKeyPath, sshPort = 22):
        import paramiko
        from paramiko import SSHClient
        from sqlalchemy import create_engine
        from sshtunnel import SSHTunnelForwarder
        from os.path import expanduser
        mypkey = paramiko.RSAKey.from_private_key_file(sshPrivateKeyPath)
        with open(databaseSecretLocation) as f:
                self.databaseSecret = json.load(f)
                self.currentDBSecret = self.databaseSecret[databaseName]
        
        self.tunnel = SSHTunnelForwarder((sshHost, sshPort), ssh_username=sshUser, ssh_pkey=mypkey, remote_bind_address=(self.currentDBSecret["server"], self.currentDBSecret["port"]))
        self.tunnel.start()
        engine_str = "postgresql://{}:{}@{}:{}/{}".format(self.currentDBSecret["user"], self.currentDBSecret["password"], '127.0.0.1', self.tunnel.local_bind_port, self.currentDBSecret["database"])
        self.engine = create_engine(engine_str)
        self.conn = self.engine.raw_connection()
        self.cursor = self.conn.cursor()

    def closeConnection(self):
        if self.tunnel is not None:
            self.tunnel.close()
        try:
            self.conn.commit()
        except:
            self.conn.rollback()
        finally:
            self.conn.close()
        

    def executeQuery(self, queryString):
        try:
            self.cursor.execute(queryString)
            self.conn.commit()
            return True
        except:
            self.conn.rollback()
            return False
            
    def s3Insert(self, pandasDataFrame, tableName):
            df = self.cleanDataFrameColumns(pandasDataFrame)
            if self.unit_testing:
                return False
            else:
                fileToUpload = "temporary_" + hashlib.md5(str(time.time()).encode()).hexdigest() + ".csv"
                df.to_csv(fileToUpload, index = None, header=False)
                if self.myS3.singleUpload(fileToUpload):
                    print("upload success")
                    copyDataFromS3Sql = self.copyDataFromS3(fileToUpload, tableName, df.columns.values)
                    print(copyDataFromS3Sql)
                    if self.executeQuery(copyDataFromS3Sql):
                        os.remove(fileToUpload)
                        self.myS3.deleteSingleFile(fileToUpload)
                        return True
                    else:
                        print("copy function fail")
                        os.remove(fileToUpload)
                        self.myS3.deleteSingleFile(fileToUpload)
                        return False
                else:
                    os.remove(fileToUpload)
                    return False

 
    def s3Upsert(self, pandasDataFrame, oriTableName, uniqueCol = "hashid", convertLargeText = True):
        tableName = oriTableName.lower()
        tempTable = "temporary_edward_upsert_" + hashlib.md5(str(time.time()).encode()).hexdigest()
        df = self.cleanDataFrameColumns(pandasDataFrame)
        assert uniqueCol in df.keys(), uniqueCol + " Not Exists"
        subDf = df.loc[:, [uniqueCol]]
        subDf = subDf.drop_duplicates([uniqueCol], keep="first")
        if self.unit_testing:
            print(subDf.head())
            return df
        else:
            createTempTableSql = self.tableCreateSqlGenerate(subDf, tempTable)
            self.executeQuery(createTempTableSql)
            self.s3Insert(subDf, tempTable)
            deleteQueryString = 'DELETE FROM ' + tableName + ' USING ' + tempTable + ' WHERE ' + tableName + '.' + uniqueCol + "=" + tempTable + "." + uniqueCol +";"
            print(deleteQueryString)
            try:
                self.cursor.execute(deleteQueryString)
                self.conn.commit()
            except:
                self.conn.rollback()
                print("This might be the first time upload")
                createTableSql = self.tableCreateSqlGenerate(df, tableName, convertLargeText=convertLargeText)
                self.executeQuery(createTableSql)
            self.dropTable(tempTable)
            self.s3Insert(df, tableName)