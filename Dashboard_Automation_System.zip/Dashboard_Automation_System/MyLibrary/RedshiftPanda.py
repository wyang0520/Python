import pandas as pd
import json
from sqlalchemy import create_engine
from enum import Enum
import numpy as np
import csv
import re
import hashlib
from tqdm import tqdm
import time

class RedshiftPanda:
    chunk_size = 1000
    def __init__(self, databaseSecretLocation, databaseName, unit_testing = False):
        self.unit_testing = unit_testing
        if not self.unit_testing:
            with open(databaseSecretLocation) as f:
                self.databaseSecret = json.load(f)
                self.currentDBSecret = self.databaseSecret[databaseName]
            engine_str = "postgresql://{}:{}@{}:{}/{}".format(self.currentDBSecret["user"], self.currentDBSecret["password"], self.currentDBSecret["server"], self.currentDBSecret["port"], self.currentDBSecret["database"])
            self.engine = create_engine(engine_str)
            self.conn = self.engine.raw_connection()
            self.cursor = self.conn.cursor()

    def convertHeaderToSqlValid(self, headerArray):
        newHeader = []
        for each in headerArray:
            newHead = re.sub('[^0-9a-zA-Z_]', '_', each)
            newHead = re.sub('^[^a-zA-Z_]+', '_', newHead)
            newHead = newHead.replace(":", "_").lower()
            newHeader.append(newHead)
        return newHeader

    # def tableNameCheck(self, tableName):
    #     if "public." in tableName:
    #         return tableName
    #     else:
    #         changeDotList = tableName.split(".")
    #         fix_dot = "_".join(changeDotList)
    #         return "public." + fix_dot

    def cleanDataFrameColumns(self, pandasDataFrame):
        df = pandasDataFrame
        headerColumn = df.columns
        validHeader = self.convertHeaderToSqlValid(headerColumn)
        df.columns = validHeader
        return df

    def pandasInsert(self, pandasDataFrame, tableName, method = "append"):
        df = self.cleanDataFrameColumns(pandasDataFrame)
        if self.unit_testing:
            return df
        else:
            df.to_sql(tableName, self.engine, if_exists=method, schema='public', index=False)

    def dropTable(self, tableName):
        dropTableQuery = 'DROP TABLE IF EXISTS ' + tableName
        if self.unit_testing:
            print(dropTableQuery)
        else:
            self.cursor.execute(dropTableQuery)
            self.conn.commit()

    def pandasInsertNew(self, pandasDataFrame, oriTableName, uniqueCol = "hashid", method = "append"):
        tableName = oriTableName.lower()
        tempTable = "temporary_edward_upsert_" + hashlib.md5(str(time.time()).encode()).hexdigest()
        df = self.cleanDataFrameColumns(pandasDataFrame)
        subDf = df.loc[:, [uniqueCol]]
        subDf = subDf.drop_duplicates([uniqueCol], keep='first')
        if self.unit_testing:
            return df
        else:
            subDf.to_sql(tempTable, self.engine, chunksize=self.chunk_size, if_exists='replace', schema='public', index=False)
            queryString = 'SELECT a.' + uniqueCol + ' FROM ' + tableName + ' a JOIN ' + tempTable + ' b on a.' + uniqueCol + ' = b.' + uniqueCol
            try:
                existData = pd.read_sql(queryString, self.engine)
                notExistsDf = df[(~df[uniqueCol].isin(existData[uniqueCol]))]
                if notExistsDf.shape[0] > 0:
                    notExistsDf.to_sql(tableName, self.engine, chunksize=self.chunk_size, if_exists=method, schema='public', index=False)
                else:
                    print("All Data already exists in the table")
                self.dropTable(tempTable)
            except:
                print("table not exists will create a table")
                df.to_sql(tableName, self.engine, chunksize=self.chunk_size, if_exists=method, schema='public', index=False)
                self.dropTable(tempTable)

    def pandasUpsert(self, pandasDataFrame, oriTableName, uniqueCol = "hashid", method = "append", chunkUpload = True, showProgress = True):
        tableName = oriTableName.lower()
        tempTable = "temporary_edward_upsert_" + hashlib.md5(str(time.time()).encode()).hexdigest()
        df = self.cleanDataFrameColumns(pandasDataFrame)
        assert uniqueCol in df.keys(), uniqueCol + " Not Exists"
        subDf = df.loc[:, [uniqueCol]]
        subDf = subDf.drop_duplicates([uniqueCol], keep='first')
        if self.unit_testing:
            print(subDf.head())
            return df
        else:
            subDf.to_sql(tempTable, self.engine, chunksize=self.chunk_size, if_exists='replace', schema='public', index=False)
            deleteQueryString = 'DELETE FROM ' + tableName + ' USING ' + tempTable + ' WHERE ' + tableName + '.' + uniqueCol + "=" + tempTable + "." + uniqueCol +";"
            print(deleteQueryString)
            try:
                self.cursor.execute(deleteQueryString)
                self.conn.commit()
            except:
                self.conn.rollback()
                print("This might be the first time upload")
            self.dropTable(tempTable)
            if chunkUpload:
                chunkNum = df.shape[0]/self.chunk_size
                if chunkNum < 1:
                    chunkNum = 1
                chunksToUpload = np.array_split(df, chunkNum, 0)
            else:
                chunksToUpload = np.array_split(df, 1, 0)
            counter = 0
            if showProgress:
                chunksToUpload = tqdm(chunksToUpload)
            for eachChunks in chunksToUpload:
                # print(counter)
                eachChunks.to_sql(tableName, self.engine, chunksize=None, if_exists=method, schema='public', index=False)
                counter += 1
            