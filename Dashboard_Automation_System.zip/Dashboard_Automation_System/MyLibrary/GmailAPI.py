from __future__ import print_function
import httplib2
import os
import time
import json
import base64
import zipfile
import email
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage
from google.cloud import pubsub_v1
from email.mime.text import MIMEText
import dateutil.parser as parser
from bs4 import BeautifulSoup
from datetime import datetime
try:
    import argparse
    flags = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flags = None

class GmailApi:
    def __init__(self, CLIENT_SECRET_FILE, storeCredentialName="savedCredential.json", reGenerate=False, SCOPE='https://www.googleapis.com/auth/gmail.modify', APPLICATION_NAME = 'Gmail API Python Quickstart', displayLog = False):
        """Create an object that allow you to implement gmail api easier.

        Args:
            CLIENT_SECRET_FILE: the secret file download from google.
            reGenerate: do you want to regenerate the credential when local credential exists
            SCOPE: permission control on gmail. Default is gmail.modify (read/write). Each time change scope, please turn reGenerate to true
            APPLICATION_NAME: the application name. No need to change

        """
        self.__SCOPE = SCOPE
        self.__CLIENT_SECRET_FILE = CLIENT_SECRET_FILE
        self.__APPLICATION_NAME = APPLICATION_NAME
        credentials = self.__get_credentials(reGenerate, storeCredentialName)
        http = credentials.authorize(httplib2.Http())
        self.__service = discovery.build('gmail', 'v1', http=http)
        self.__verbose = displayLog
        if self.__verbose:
            print("Gmail Api Setup")
    
    def __get_credentials(self, reGenerate, storeCredential):
        """Gets valid user credentials from storage.

        If nothing has been stored, or if the stored credentials are invalid,
        the OAuth2 flow is completed to obtain the new credentials.
        Args:
            reGenerate: do you want to regenerate the credential when local credential exists
        Returns:
            Credentials, the obtained credential.
        """
        home_dir = os.path.expanduser('~')
        credential_dir = os.path.join(home_dir, '.credentials')
        if not os.path.exists(credential_dir):
            os.makedirs(credential_dir)
        credential_path = os.path.join(credential_dir,
                                    storeCredential)
        if os.path.exists(credential_path) and reGenerate:
            os.remove(credential_path)
        store = Storage(credential_path)
        credentials = store.get()
        if not credentials or credentials.invalid:
            flow = client.flow_from_clientsecrets(self.__CLIENT_SECRET_FILE, self.__SCOPE)
            flow.user_agent = self.__APPLICATION_NAME
            if flags:
                credentials = tools.run_flow(flow, store, flags)
            else: # Needed only for compatibility with Python 2.6
                credentials = tools.run(flow, store)
            print('Storing credentials to ' + credential_path)
        return credentials
    
    def startPublishGmailNotification(self, project_name, topic_name, label_id_list = ["UNREAD"]):
        """Connect gmail to pub_sub function in google. Start publishing notification to pub_sub
        Need to setup pub_sub function in google api and configure it correctly.
        More information please check GmailNotification().help()
        
        Args:
            project_name: pub_sub project name
            topic_name: pub_sub topic name
            label_id_list: check email changes with these labels           
    
        Returns:
            gmail watch function result
        """
        topic_path = 'projects/{project_id}/topics/{topic}'.format(project_id=project_name,topic=topic_name)
        request = {
            'labelIds': label_id_list,
            'topicName': topic_path
        }
        result = self.__service.users().watch(userId='me', body=request).execute()
        if self.__verbose:
            print("Start Publish Notification Success: {}".format(result))
        return result

    def ListMessagesWithLabels(self, user_id="me", label_ids=["UNREAD"]):
        """List all Messages of the user's mailbox with label_ids applied.

        Args:
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            label_ids: Only return Messages with these labelIds applied.

        Returns:
            List of Messages that have all required Labels applied. Note that the
            returned list contains Message IDs, you must use get with the
            appropriate id to get the details of a Message.
        """
        response = self.__service.users().messages().list(userId=user_id, labelIds=label_ids).execute()
        messages = []
        if 'messages' in response:
            messages.extend(response['messages'])

        while 'nextPageToken' in response:
            page_token = response['nextPageToken']
            response = self.__service.users().messages().list(userId=user_id,
                                                        labelIds=label_ids,
                                                        pageToken=page_token).execute()
            messages.extend(response['messages'])

        return messages

    def GetMessage(self, gmailMessage = None, msg_id = None, user_id="me"):   
        """Get full email information from Message or given id.

        Args:
            gmailMessage: the message object get from gmail api.
            msg_id: ID of Message containing attachment.
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            *: If both gmailMessage and msg_id provided, will use msg_id.
        """
        if gmailMessage == None and msg_id == None:
            return {}
        temp_dict = {}
        message = gmailMessage # fetch the message using API
        if msg_id != None:
            message = self.__service.users().messages().get(userId=user_id, id=msg_id).execute()
        payld = message['payload'] # get payload of the message 
        headr = payld['headers'] # get header of the payload
        # print(self.GetMimeMessage(user_id, msg_id))

        for one in headr: # getting the Subject
            if one['name'] == 'Subject':
                msg_subject = one['value']
                temp_dict['Subject'] = msg_subject
            else:
                pass


        for two in headr: # getting the date
            if two['name'] == 'Date':
                msg_date = two['value']
                date_parse = (parser.parse(msg_date))
                m_date = (date_parse.date())
                temp_dict['Date'] = str(m_date)
            else:
                pass

        for three in headr: # getting the Sender
            if three['name'] == 'From':
                msg_from = three['value']
                temp_dict['Sender'] = msg_from
            else:
                pass

        temp_dict['Snippet'] = message['snippet'] # fetching message snippet

        try:
            
        # Fetching message body
        # print(payld)
        # mssg_parts = payld['parts'] # fetching the message parts
        # part_one  = mssg_parts[0] # fetching first element of the part 
            part_body = payld['body'] # fetching body of the message
            part_data = part_body['data'] # fetching data from the body
            clean_one = part_data.replace("-","+") # decoding from Base64 to UTF-8
            clean_one = clean_one.replace("_","/") # decoding from Base64 to UTF-8
            clean_two = base64.b64decode (bytes(clean_one, 'UTF-8')) # decoding from Base64 to UTF-8
            # print(clean_two)
            soup = BeautifulSoup(clean_two , "lxml" )
            mssg_body = soup.body()
            # mssg_body is a readible form of message body
            # depending on the end user's requirements, it can be further cleaned 
            # using regex, beautiful soup, or any other method
            mssg_body_arr_p = soup.find_all('p')
            mssg_body_arr_a = soup.find_all('a', href=True)
            mssg_body_arr = []
            mssg_body_a = []
            for eachP in mssg_body_arr_p:
                mssg_body_arr.append(str(eachP))
            for eachA in mssg_body_arr_a:
                mssg_body_a.append(eachA['href'])
            temp_dict['Message_body'] = mssg_body_arr
            temp_dict['Message_body_link'] = mssg_body_a
        except :
            try:
                mssg_parts = payld['parts'] # fetching the message parts
                part_one  = mssg_parts[0] # fetching first element of the part 
                part_body = part_one['body'] # fetching body of the message
                part_data = part_body['data'] # fetching data from the body
                clean_one = part_data.replace("-","+") # decoding from Base64 to UTF-8
                clean_one = clean_one.replace("_","/") # decoding from Base64 to UTF-8
                clean_two = base64.b64decode (bytes(clean_one, 'UTF-8')) # decoding from Base64 to UTF-8
                # print(clean_two)
                soup = BeautifulSoup(clean_two , "lxml" )
                mssg_body = soup.body()
                # print(len(mssg_body))
                mssg_body_arr_p = soup.find_all('p')
                mssg_body_arr_a = soup.find_all('a', href=True)
                mssg_body_arr = []
                mssg_body_a = []
                for eachP in mssg_body_arr_p:
                    mssg_body_arr.append(str(eachP))
                for eachA in mssg_body_arr_a:
                    mssg_body_a.append(eachA['href'])
                temp_dict['Message_body'] = mssg_body_arr
                temp_dict['Message_body_link'] = mssg_body_a
                # mssg_body is a readible form of message body
                # depending on the end user's requirements, it can be further cleaned 
                # using regex, beautiful soup, or any other method
                # temp_dict['Message_body'] = mssg_body[0]
            except:
                pass
    
        return temp_dict

    def GetAttachments(self, msg_id, store_dir, user_id="me", getEmailMessage=True, autoUnzip=True, keepZipFile=False):
        """Get and store attachment from Message with given id.

        Args:
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            msg_id: ID of Message containing attachment.
            store_dir: The directory used to store attachments.
            autoUnzip: automatically unzip zip attachment
            keepZipFile: after auto unzip the file do not delete the original zip file
        """
        message = self.__service.users().messages().get(userId=user_id, id=msg_id).execute()
        fileCount = 0
        fileName = []
        time = datetime.now()
        add_file_name = time.strftime("%d-%b-%Y")
        emailInfo = {}
        if getEmailMessage:
            emailInfo = self.GetMessage(message)
        for part in message['payload']['parts']:
            if part['filename']:
                fileName.append(part['filename'])
                if 'data' in part['body']:
                    data=part['body']['data']
                else:
                    att_id=part['body']['attachmentId']
                    att=self.__service.users().messages().attachments().get(userId=user_id, messageId=msg_id,id=att_id).execute()
                    data=att['data']
                file_data = base64.urlsafe_b64decode(data.encode('UTF-8'))
                path = os.path.join(store_dir, part['filename'])
                f = open(path, 'wb')
                f.write(file_data)
                f.close()
                theFileName = part['filename']
                fileType = theFileName.split('.').pop()
                if self.__verbose:
                    print(fileType)
                if autoUnzip and zipfile.is_zipfile(path) and fileType=="zip":
                    self.UnzipFile(path, store_dir)
                    if not keepZipFile:
                        os.remove(path)
                fileCount += 1
        if self.__verbose:
            print("Save {} files".format(fileCount))
        return {'fileCount': fileCount, 'fileName': fileName, 'emailInfo': emailInfo}

    def RemoveMessageLabel(self, msg_id, removeLabelIds=["UNREAD"], user_id="me"):
        """Modify the Labels on the given Message.

        Args:
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            msg_id: The id of the message required.
            removeLabelIds: list of label_ids need to be removed from the message

        Returns:
            Modified message, containing updated labelIds, id and threadId.
        """
        msgSendBody = {"removeLabelIds": removeLabelIds}
        message = self.__service.users().messages().modify(userId=user_id, id=msg_id, body=msgSendBody).execute()
        label_ids = message['labelIds']
        if self.__verbose:
            print('Message ID: %s - With Label IDs %s' % (msg_id, label_ids))
        return message

    def AddMessageLabel(self, msg_id, addLabelIds, user_id="me"):
        """Modify the Labels on the given Message.

        Args:
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            msg_id: The id of the message required.
            addLabelIds: list of label_ids need to be added to the message

        Returns:
            Modified message, containing updated labelIds, id and threadId.
        """
        msgSendBody = {"addLabelIds": addLabelIds}
        message = self.__service.users().messages().modify(userId=user_id, id=msg_id, body=msgSendBody).execute()

        label_ids = message['labelIds']
        if self.__verbose:
            print('Message ID: %s - With Label IDs %s' % (msg_id, label_ids))
        return message

    def UnzipFile(self, zipfile_path, unzip_to_path):
        with zipfile.ZipFile(zipfile_path,"r") as zip_ref:
            zip_ref.extractall(unzip_to_path)

    def create_message(self, sender, to, subject, message_text):
        """Create a message for an email.

        Args:
            sender: Email address of the sender.
            to: Email address of the receiver.
            subject: The subject of the email message.
            message_text: The text of the email message.

        Returns:
            An object containing a base64url encoded email object.
        """
        message = MIMEText(message_text)
        message['to'] = to
        message['from'] = sender
        message['subject'] = subject
        raw = base64.urlsafe_b64encode(message.as_bytes())
        raw = raw.decode()
        return {'raw': raw}

    def send_message(self, message, user_id="me"):
        """Send an email message.

        Args:
            user_id: User's email address. The special value "me"
            can be used to indicate the authenticated user.
            message: Message to be sent.

        Returns:
            Sent Message.
        """
        message = (self.__service.users().messages().send(userId=user_id, body=message).execute())
        if self.__verbose:
            print('Message Id: %s' % message['id'])
        return message

    def testFunction(self):
        results = self.__service.users().labels().list(userId='me').execute()
        labels = results.get('labels', [])

        if not labels:
            print('No labels found.')
        else:
            print('Labels:')
            for label in labels:
                print(label)

    
class GmailNotification:
    def __init__(self, pub_sub_credential_json_path):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = pub_sub_credential_json_path
        self.__subscriber = pubsub_v1.SubscriberClient()
        self.__publisher = pubsub_v1.PublisherClient()

    def help(self):
        print("https://cloud.google.com/pubsub/docs/how-to")
        print("https://googlecloudplatform.github.io/google-cloud-python/latest/pubsub/")
        print("https://console.cloud.google.com/cloudpubsub/topicList")
        print("https://developers.google.com/gmail/api/guides/push")
        print("Need to add ~gmail-api-push@system.gserviceaccount.com~ to topic permission as publisher")
        print("Need to add all members as subscriber if need to receive message")

    def create_pub_sub_topic(self, project_name, topic_name):
        """Create a topic to a project. Remeber to modify the permission as well in google dashboard"""
        # The resource path for the new topic contains the project ID
        # and the topic name.
        topic_path = self.__publisher.topic_path(project_name, topic_name)
        # Create the topic.
        topic = self.__publisher.create_topic(topic_path)
        print('Topic created: {}'.format(topic))

    def create_subscription_to_topic(self, project_name, topic_name, subscription_name):
        """Create a subscription to a topic"""
        topic = 'projects/{project_id}/topics/{topic}'.format(project_id=project_name,topic=topic_name)
        subscription_path = 'projects/{project_id}/subscriptions/{sub}'.format(project_id=project_name,sub=subscription_name)
        subscription = self.__subscriber.create_subscription(subscription_path, topic)
        print('Subscription created: {}'.format(subscription))
    
    def __default_receive_messages_callback(message):
        """Default callback function when receive a message"""
        print(message)
        message.ack()

    def receive_messages(self, project, subscription_name, Callback = __default_receive_messages_callback):
        """Receives messages from a pull subscription."""
        subscription_path = self.__subscriber.subscription_path(project, subscription_name)
        print(subscription_path)
        self.__subscriber.subscribe(subscription_path, callback=Callback)
        print('Listening for messages on {}'.format(subscription_path))
        while True:
            time.sleep(60)
