from collections import namedtuple
import pandas as pd
import types
import datetime
import csv
import hashlib
import json
import os
import re
import codecs

class Struct(object):
    """convert object to be able to read sub object through dot. (obj['subobj'] to obj.subobj)

        Args:
            object: original object
            
        Returns:
            object: structured data
    """
    def __new__(cls, data):
        if isinstance(data, dict):
            return namedtuple(
                'Struct', data.keys()
            )(
                *(Struct(val) for val in data.values())
            )
        elif isinstance(data, (tuple, list, set, frozenset)):
            return type(data)(Struct(_) for _ in data)
        else:
            return data


def changeFileName(file):
    """
        add today'date to a flie name
        for example: if filename is test.csv, then output will be test_01_01_2019.csv
    """
    time = datetime.datetime.now()
    add_file_name = time.strftime("%d_%b_%Y")
    for i in range(0,len(file)):
        if file[i] == ".":
            return file[:i]+"_"+add_file_name+file[i:]
 
def readExcelConcat(directoryPath, addFileInfo = True, readAllSheetsExcept=None, onlyReadSheet=None):
    """Read excel file in diarectory and concat into one single dataframe (All the excel must have exact format, exact columns)

        Args:
            directoryPath: the directory to read all the excel
            addFileInfo: if set to true, will add "file" column that represent the filename and "sheetName" column

        Returns:
            allConcat: aggregated dataframe
    """
    allData = []
    for eachFile in os.listdir(directoryPath):
        if "~$" in eachFile:
            continue
        if ".xls" not in eachFile:
            continue
        filePath = os.path.join(directoryPath, eachFile)
        print(filePath)
        xlsFile = pd.ExcelFile(filePath)
        for eachSheet in xlsFile.sheet_names:
            if readAllSheetsExcept is not None and isinstance(readAllSheetsExcept, list):
                if eachSheet in readAllSheetsExcept:
                    continue
            if onlyReadSheet is not None and isinstance(onlyReadSheet, list):
                if eachSheet not in onlyReadSheet:
                    continue
            df = pd.read_excel(xlsFile, eachSheet, header=0)
            if addFileInfo:
                df["file"] = filePath
                df["sheetName"] = eachSheet
            allData.append(df)
    allConcat = pd.concat(allData, sort=False)
    return allConcat


def convertDate(inputValue, oriFormat, toFormat): 
    """Convert string date value to specific format

        Args:
            inputValue: original date value in String
            oriFormat: original format (oriFormat = "%Y-%m-%d %H:%M:%S")
            toFormat: return format (toFormat = '%m/%d/%Y')

        Returns:
            returnString: reformated date value in string
    """
    d = datetime.datetime.strptime( str(inputValue), oriFormat )
    returnString = str(d.strftime(toFormat))   
    return returnString


def reFormatDataFrames(dataFrame, mapping, fixed = {}):
    """DON'T CALL THIS FUNCTION. INTERNAL(Map and create fix columns)

        Args:
            dataFrame: original dataframe need to be reformat.
            mapping: Mapping dictionary that defines how to reformat(Please check the mapping sample)
            fixed: Dictionary that defines how to create fix value columns

        Returns:
            newDF: reformated dataframe
    """
    needColumns = list(mapping.values())
    newColumnNames = list(mapping.keys())
    newDF = dataFrame[needColumns]
    newDF.columns = newColumnNames
    for eachFix in fixed.keys():
        newDF[eachFix] = fixed[eachFix]
    return newDF

def createMappingList(oriColumn, mapping):
    """DON'T CALL THIS FUNCTION. INTERNAL(generate specific dictionaries for the dataReformat function)

        Args:
            oriColumn: original dataframe columns.
            mapping: Mapping dictionary that defines how to reformat(Please check the mapping sample)

        Returns:
            mapDict: Mapping old columns to new columns
            fixDict: Create Columns with fixed value
            listDict: merge string value columns
            applyDict: apply specific function to a column
    """
    listDict = {}
    mapDict = {}
    fixDict = {}
    applyDict = {}
    if "MapAllExcept" in mapping.keys():
        dontMap = mapping["MapAllExcept"]
        for eachColumnName in oriColumn:
            if eachColumnName in dontMap:
                continue
            else:
                mapDict[eachColumnName] = eachColumnName
    for k, v in mapping.items():
        if k == "MapAllExcept":
            continue
        if isinstance(v, list):
            listDict[k] = v
        elif isinstance(v, str):
            if v in oriColumn:
                mapDict[k] = v
            else:
                fixDict[k] = v
        elif isinstance(v, dict):
            if "fix" in v.keys():
                if not isinstance(v["fix"], str):
                    try:
                        int(v["fix"])
                    except:
                        raise ValueError("fix value must be a string or number")
                fixDict[k] = v["fix"]
            elif "function" in v.keys() and isinstance(v["function"], types.FunctionType):
                applyDict[k] = v
    return (listDict, mapDict, fixDict, applyDict)

def dataFrameReformat(dataFrame, mapping, addHashId = True):
    """Reformat panda dataframe based on the mapping configuration. 
    (The reformat order is always mapping -> fix -> list -> apply)

        Args:
            dataFrame: Original dataframe need to be reformat.
            mapping: Mapping dictionary that defines how to reformat(Please check the mapping sample)

        Returns:
            newDataFrame: Reformatted dataFrame.
    """
    if not isinstance(mapping, dict):
        raise ValueError("mapping must be a dictionary")
    oriColumn = dataFrame.columns
    (listDict, mapDict, fixDict, applyDict) = createMappingList(oriColumn, mapping)
    newDF = reFormatDataFrames(dataFrame, mapDict, fixDict)
    for eachList in listDict.keys():
        evalString = ""
        counter = 0
        for eachValue in listDict[eachList]:
            if counter != 0:
                evalString += " + "
            else:
                counter += 1
            if eachValue in newDF.columns:
                evalString = evalString + "newDF['" + eachValue + "']"
            elif eachValue in oriColumn:
                evalString = evalString + "dataFrame['" + eachValue + "']"
            else:
                evalString = evalString + "'" + eachValue + "'"
        newDF[eachList] = eval(evalString)
    for eachApply in applyDict.keys():
        if "oriColumn" in applyDict[eachApply].keys() and applyDict[eachApply]["oriColumn"] in oriColumn:
            newDF[eachApply] = dataFrame[applyDict[eachApply]["oriColumn"]].apply(applyDict[eachApply]["function"])
        elif "newColumn" in applyDict[eachApply].keys() and applyDict[eachApply]["newColumn"] in newDF.columns:
            newDF[eachApply] = newDF[applyDict[eachApply]["newColumn"]].apply(applyDict[eachApply]["function"])
        else:
            newDF[eachApply] = dataFrame[eachApply].apply(applyDict[eachApply]["function"])
    if addHashId:
        newDF["hashId"] = newDF.apply(lambda x: hashlib.md5(json.dumps(tuple(x), default=str).encode()).hexdigest(), axis = 1)
    return newDF

def _rangeGenerator(inputRange):
    newRange = []
    for eachRange in inputRange:
        if isinstance(eachRange, int):
            newRange.append(eachRange)
        else:
            newRange += range(inputRange[0][0], inputRange[0][1]+1)
    return newRange


def extractCsvData(csv_path, checkColumn, checkColumnLen,convertToIntRange=[], convertToFloatRange=[], convertToIntWithString=[], convertToFloatWithString=[], convertIntFailDefault=-5, convertFloatFailDefault=-5.0, hasHeader = True, stopWithCheckColumn=True, exportDataFrame = True, includeCsvFileName = False):
    """Extract data from csv file and remove unnessary columns and do convertion to specific columns

        Args:
            csv_path: csv file need to be extracted from.
            checkColumn: check if column in current row has value, if not skip this row
            checkColumnLen: check if row has this number of columns, otherwise skip this row
            convertToIntRange: convert all columns in this list to integer, if conversion fail will error out
            convertToFloatRange: convert all columns in this list to float, if conversion fail will error out
            convertToIntWithString: convert all columns in this list to integer, if conversion fail will replace the value to preset value
            convertToFloatWithString: convert all columns in this list to Float, if conversion fail will replace the value to preset value
            convertIntFailDefault: when convert to int fail use this value instead
            convertFloatFailDefault: when convert to float fail use this value instead
            hasHeader: will skip the first row and return first row as header, please set to false if dataset don't have header
            stopWithCheckColumn: when checkColumn don't have value, then stop the process and return current result
            subject: The subject of the email message.
            message_text: The text of the email message.

        Returns:
            header: if hasHeader is true, this will be the first row from csv datafile
            extractData: an array of tuples, each tuple is a row of csv datafile
            extractDataWithHash: and array of tuples, add a hashed id as first element in each tuple. The hashed if is based on current row value. Will be the same for duplicate rows.
    """
    with codecs.open(csv_path, 'r', encoding="utf8", errors="replace") as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        firstLineDetect = 0
        header = None
        hashHeader = None
        extractData = []
        extractDataWithHash = []
        for row in spamreader:
            if len(row) < checkColumnLen:
                # print(len(row))
                if stopWithCheckColumn:
                    break
                else:
                    continue
            if isinstance(checkColumn, list):
                fulfillCheck = True
                for eachCheckColumn in checkColumn:
                    if not row[eachCheckColumn] or row[eachCheckColumn].strip() == "" or len(row[eachCheckColumn]) == 0:
                        fulfillCheck = False
                        break
                if not fulfillCheck:
                    if stopWithCheckColumn:
                        break
                    else:
                        continue
            else:
                if not row[checkColumn] or row[checkColumn].strip() == "" or len(row[checkColumn]) == 0:
                    if stopWithCheckColumn:
                        break
                    else:
                        continue
            if(firstLineDetect == 0 and hasHeader):
                header = row
                hashHeader = list(header)
                hashHeader.insert(0, "hashId")
                firstLineDetect += 1
            else:
                manipulateRow = row
                for each in _rangeGenerator(convertToIntRange):
                    # print(re.sub('[^0-9.]', '', manipulateRow[each]))
                    manipulateRow[each] = int(re.sub('[^0-9.]', '', manipulateRow[each]))
                for eachFloat in _rangeGenerator(convertToFloatRange):
                    if "%" in manipulateRow[eachFloat]:
                        convertToFloat = float(re.sub('[^0-9.]', '', manipulateRow[eachFloat]))
                        manipulateRow[eachFloat] = convertToFloat / 100
                    else:
                        manipulateRow[eachFloat] = float(re.sub('[^0-9.]', '', manipulateRow[eachFloat]))
                for eachIntWithString in _rangeGenerator(convertToIntWithString):   
                    try:
                        manipulateRow[eachIntWithString] = int(re.sub('[^0-9.]', '', manipulateRow[eachIntWithString]))
                    except:
                        manipulateRow[eachIntWithString] = convertIntFailDefault
                for eachFloatWithString in _rangeGenerator(convertToFloatWithString):
                    try:
                        if "%" in manipulateRow[eachFloatWithString]:
                            convertToFloat = float(re.sub('[^0-9.]', '', manipulateRow[eachFloatWithString]))
                            manipulateRow[eachFloatWithString] = convertToFloat / 100
                        else:
                            manipulateRow[eachFloatWithString] = float(re.sub('[^0-9.]', '', manipulateRow[eachFloatWithString]))
                    except:
                        manipulateRow[eachFloatWithString] = convertFloatFailDefault
                hashId = hashlib.md5(json.dumps(tuple(manipulateRow)).encode()).hexdigest()
                rowWithHash = [str(hashId)] + manipulateRow
                extractData.append(tuple(manipulateRow))
                extractDataWithHash.append(tuple(rowWithHash)) 
        if exportDataFrame:
            # print(csv_path)
            hashedFinishDF = pd.DataFrame(extractDataWithHash, columns = hashHeader)
            if includeCsvFileName:
                hashedFinishDF["csvFileName"] = csv_path.split("/")[-1]
            if "hashId" in header: header.remove("hashId")
            finishDF = pd.DataFrame(extractData, columns = header)
            if includeCsvFileName:
                finishDF["csvFileName"] = csv_path.split("/")[-1]
            return (finishDF, hashedFinishDF)
        else:
            return (header, extractData, hashHeader, extractDataWithHash)
    