import urllib
import html.parser
import wget
import requests
import re
import time
import os

def getFinalRedirectUrl(originalUrl):
    currentUrl = originalUrl
    headers = {'User-Agent': 'Mozilla/5.0 (X11; OpenBSD i386) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36'}
    req = urllib.request.Request(originalUrl, headers=headers)
    getRedirectUrl = urllib.request.urlopen(req).geturl()
    counter = 0
    while currentUrl != getRedirectUrl and counter < 10:
        currentUrl = getRedirectUrl
        req = urllib.request.Request(originalUrl, headers=headers)
        getRedirectUrl = urllib.request.urlopen(req).geturl()
        counter += 1
    return getRedirectUrl

def fixUrlEscape(originalUrl):
    fixEscape = html.parser.HTMLParser().unescape(originalUrl)
    if 'http' in fixEscape:
        finalUrl = 'http' + fixEscape.split('http')[1]
        return finalUrl
    return fixEscape

def _get_filename_from_cd(cd):
    """
    Get filename from content-disposition
    """
    if not cd:
        return None
    fname = re.findall('filename=(.+)', cd)
    if len(fname) == 0:
        return None
    return fname[0]

def downloadFile(downloadUrl, directory=None, filename=None, setExtention="", noDuplicate = True):
    r = requests.get(downloadUrl, allow_redirects=True)
    theFileName = filename
    if filename is None:
        theFileName = _get_filename_from_cd(r.headers.get('content-disposition'))
        if theFileName is not None:
            theFileName = theFileName.replace('"', "")
            if noDuplicate:
                theFileName = str(int(time.time())) + theFileName
    if theFileName is None:
        theFileName = str(int(time.time())) + setExtention
    if directory is not None:
        theFileName = os.path.join(directory, theFileName)
        # print(theFileName)
    open(theFileName, 'wb').write(r.content)


    

