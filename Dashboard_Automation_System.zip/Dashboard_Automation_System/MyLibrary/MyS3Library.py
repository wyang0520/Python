import math, os
import boto
from boto.s3.connection import S3Connection
from boto.s3.key import Key
from filechunkio import FileChunkIO
from boto.s3.connection import Location
import ntpath

def _printProgress(complete, total):
    try:
        print(str(complete/total*100) + '%')
    except:
        print("complete: " + str(complete) + " total: " + str(total))

class MyS3:
    def __init__(self, awsAccessKey, awsSecretKey):
        self.bucket = None
        self.conn = S3Connection(awsAccessKey, awsSecretKey, host=S3Connection.DefaultHost)
    
    def listAllBucket(self):
        rs = self.conn.get_all_buckets()
        for b in rs:
            print(b.name)
        return rs

    def connectToBucket(self, bucketName):
        self.bucket = self.conn.get_bucket(bucketName, validate=False)

    def _checkFileSize(self, filePath):
        return os.stat(filePath).st_size
    
    def createBucket(self, bucketName, setLocation = Location.DEFAULT):
        return self.conn.create_bucket(bucketName, location=setLocation)

    def deleteSingleFile(self, key):
        if self.bucket is None:
            raise Exception('Need to connect to a bucket first!!')
        k = Key(self.bucket)
        k.key = key
        k.delete()


    def listBucketFile(self):
        if self.bucket is None:
            raise Exception('Need to connect to a bucket first!!')
        fList = self.bucket.list()
        for file in fList:
            print(file.name)
        return fList

    def multipartUpload(self, filePath, chunkSizeMB = 50, progress = _printProgress):
        if self.bucket is None:
            raise Exception('Need to connect to a bucket first!!')
        mp = self.bucket.initiate_multipart_upload(os.path.basename(filePath))
        chunkSize = chunkSizeMB * 1024 * 1024
        fileSize = self._checkFileSize(filePath)
        chunkCount = int(math.ceil(fileSize/float(chunkSize)))
        for i in range(chunkCount):
            offset = chunkSize * i
            bytes = min(chunkSize, fileSize - offset)
            with FileChunkIO(filePath, 'r', offset=offset, bytes=bytes) as fp:
                try:
                    mp.upload_part_from_file(fp, part_num=i + 1)
                except:
                    return False
            progress(offset, fileSize)
        mp.complete_upload()
        return True

    def singleUpload(self, filePath, key = None, progress = _printProgress):
        if self.bucket is None:
            raise Exception('Need to connect to a bucket first!!')
        k = Key(self.bucket)
        if key is None:
            k.key = ntpath.basename(filePath)
        else:
            k.key = key
        fileSize = self._checkFileSize(filePath)
        sent = k.set_contents_from_filename(filePath, cb=progress)
        if sent == fileSize:
            return True
        return False
